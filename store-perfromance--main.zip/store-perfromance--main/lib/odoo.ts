import xmlrpc from "xmlrpc";

const ODOO_URL = process.env.ODOO_URL!.replace(/\/$/, "");
const ODOO_DB = process.env.ODOO_DB!;
const ODOO_USERNAME = process.env.ODOO_USERNAME!;
const ODOO_API_KEY = process.env.ODOO_API_KEY!;
const WEBSITE_ID = 3; // Uncompromised

// Singleton uid promise — prevents concurrent authenticate calls
let _uidPromise: Promise<number> | null = null;

const OBJ_CLIENT = (() => {
  const url = new URL(ODOO_URL);
  const opts = { host: url.hostname, port: url.protocol === "https:" ? 443 : 80, path: "/xmlrpc/2/object" };
  return url.protocol === "https:" ? xmlrpc.createSecureClient(opts) : xmlrpc.createClient(opts);
})();

async function call<T>(method: string, params: unknown[]): Promise<T> {
  return new Promise((resolve, reject) => {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    OBJ_CLIENT.methodCall(method, params, (err: any, value: T) => {
      if (err) reject(err);
      else resolve(value);
    });
  });
}

async function getUid(): Promise<number> {
  if (!_uidPromise) {
    const url = new URL(ODOO_URL);
    const opts = { host: url.hostname, port: url.protocol === "https:" ? 443 : 80, path: "/xmlrpc/2/common" };
    const common = url.protocol === "https:" ? xmlrpc.createSecureClient(opts) : xmlrpc.createClient(opts);
    _uidPromise = new Promise<number>((resolve, reject) => {
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      common.methodCall("authenticate", [ODOO_DB, ODOO_USERNAME, ODOO_API_KEY, {}], (err: any, val: number) => {
        if (err) { _uidPromise = null; reject(err); }
        else resolve(val);
      });
    });
  }
  return _uidPromise;
}

const delay = (ms: number) => new Promise((r) => setTimeout(r, ms));

// ── Concurrency limiter ───────────────────────────────────────────────────────
// Odoo SaaS rejects concurrent requests on the same connection with an HTML
// rate-limit page ("Unknown XML-RPC tag 'TITLE'"). Cap in-flight calls to 2.
const MAX_CONCURRENT = 2;
let _inFlight = 0;
const _queue: Array<() => void> = [];

function acquireSlot(): Promise<void> {
  if (_inFlight < MAX_CONCURRENT) {
    _inFlight++;
    return Promise.resolve();
  }
  return new Promise((resolve) => _queue.push(resolve));
}

function releaseSlot() {
  const next = _queue.shift();
  if (next) {
    next(); // hand the slot directly to the next waiter
  } else {
    _inFlight--;
  }
}

const ODOO_MAX_RECORDS = 10_000; // Odoo SaaS hard cap

async function execute<T>(model: string, method: string, args: unknown[], kwargs: Record<string, unknown> = {}): Promise<T> {
  await acquireSlot();
  const uid = await getUid();
  try {
    const result = await call<T>("execute_kw", [ODOO_DB, uid, ODOO_API_KEY, model, method, args, kwargs]);
    // Warn if we're near the Odoo SaaS record cap (silent truncation risk)
    if (Array.isArray(result) && result.length >= ODOO_MAX_RECORDS * 0.9) {
      console.warn(`[odoo] WARNING: ${model}.${method} returned ${result.length} records — approaching the ${ODOO_MAX_RECORDS} cap. Consider narrowing the date range.`);
    }
    return result;
  } finally {
    releaseSlot();
  }
}

export type POSOrder = {
  id: number;
  name: string;
  state: string; // draft | paid | done | invoiced | cancel
  date_order: string;
  amount_total: number;
  partner_id: [number, string] | false;
};

export type OdooOrder = {
  id: number;
  name: string;
  state: string;
  date_order: string;
  amount_total: number;
  amount_delivery: number;
  amount_untaxed?: number;
  amount_tax?: number;
  partner_id: [number, string];
  partner_shipping_id?: [number, string] | false;
  invoice_status: string;
  delivery_status: string | false;
  cart_quantity: number;
  note?: string | false;
  carrier_id?: [number, string] | false;
};

export type OdooPicking = {
  id: number;
  name: string;
  state: string;
  scheduled_date: string | false;
  partner_id: [number, string] | false;
  sale_id: [number, string] | false;
};

export const odoo = {
  WEBSITE_ID,

  // Single sale.order fetch — confirmed/cart/all-orders are derived in JS
  async getOrdersInPeriod(dateFrom: string, dateTo: string): Promise<OdooOrder[]> {
    return execute<OdooOrder[]>("sale.order", "search_read", [
      [
        ["website_id", "=", WEBSITE_ID],
        ["date_order", ">=", `${dateFrom} 00:00:00`],
        ["date_order", "<=", `${dateTo} 23:59:59`],
      ],
    ], {
      fields: ["id", "name", "state", "date_order", "amount_total", "amount_delivery",
               "partner_id", "invoice_status", "delivery_status", "cart_quantity"],
      order: "date_order desc",
      limit: 0,
    });
  },

  // Fetches all-time website order history for given partners (new/repeat classification)
  async getOrderHistoryForPartners(partnerIds: number[]): Promise<{ partner_id: [number, string]; date_order: string }[]> {
    if (!partnerIds.length) return [];
    return execute("sale.order", "search_read", [
      [
        ["website_id", "=", WEBSITE_ID],
        ["state", "in", ["sale", "done"]],
        ["partner_id", "in", partnerIds],
      ],
    ], {
      fields: ["partner_id", "date_order"],
      order: "date_order asc",
      limit: 0,
    });
  },

  // Fetches all-time POS order history for given partners (new/repeat classification)
  async getPOSOrderHistoryForPartners(partnerIds: number[]): Promise<{ partner_id: [number, string] | false; date_order: string }[]> {
    if (!partnerIds.length) return [];
    return execute("pos.order", "search_read", [
      [
        ["partner_id", "in", partnerIds],
        ["state", "in", ["paid", "done", "invoiced"]],
      ],
    ], {
      fields: ["partner_id", "date_order"],
      order: "date_order asc",
      limit: 0,
    });
  },

  // Single stock.picking fetch — pending/dispatched counts derived in JS
  async getPickingsInPeriod(dateFrom: string, dateTo: string): Promise<(OdooPicking & { date_done: string | false })[]> {
    return execute("stock.picking", "search_read", [
      [
        ["picking_type_code", "=", "outgoing"],
        ["sale_id", "!=", false],
        ["scheduled_date", ">=", `${dateFrom} 00:00:00`],
        ["scheduled_date", "<=", `${dateTo} 23:59:59`],
      ],
    ], {
      fields: ["id", "name", "state", "scheduled_date", "date_done", "partner_id", "sale_id"],
      order: "scheduled_date asc",
      limit: 0,
    });
  },

  async getVisitors(dateFrom: string, dateTo: string): Promise<number> {
    return execute<number>("website.visitor", "search_count", [
      [
        ["website_id", "=", WEBSITE_ID],
        ["create_date", ">=", `${dateFrom} 00:00:00`],
        ["create_date", "<=", `${dateTo} 23:59:59`],
      ],
    ]);
  },

  async getTotalVisitors(): Promise<number> {
    return execute<number>("website.visitor", "search_count", [
      [["website_id", "=", WEBSITE_ID]],
    ]);
  },

  // Single pos.order fetch for the period
  async getPOSOrdersInPeriod(dateFrom: string, dateTo: string): Promise<POSOrder[]> {
    return execute<POSOrder[]>("pos.order", "search_read", [
      [
        ["date_order", ">=", `${dateFrom} 00:00:00`],
        ["date_order", "<=", `${dateTo} 23:59:59`],
        ["state", "!=", "cancel"],
      ],
    ], {
      fields: ["id", "name", "state", "date_order", "amount_total", "partner_id"],
      order: "date_order desc",
      limit: 0,
    });
  },

  // ── Order detail (read-only) ──────────────────────────────────────────────

  async getOrderById(id: number) {
    return execute<OdooOrder[]>("sale.order", "search_read", [
      [["id", "=", id], ["website_id", "=", WEBSITE_ID]],
    ], {
      fields: ["id", "name", "state", "date_order", "amount_total", "amount_delivery",
               "amount_untaxed", "amount_tax", "partner_id", "partner_shipping_id",
               "invoice_status", "delivery_status", "note", "carrier_id"],
      limit: 1,
    });
  },

  async getOrderLines(orderId: number) {
    return execute<{
      id: number;
      product_id: [number, string] | false;
      name: string;
      product_uom_qty: number;
      price_unit: number;
      price_subtotal: number;
      price_total: number;
      discount: number;
      product_uom_id: [number, string] | false;
      qty_delivered: number;
      qty_invoiced: number;
    }[]>("sale.order.line", "search_read", [
      [["order_id", "=", orderId]],
    ], {
      fields: ["id", "product_id", "name", "product_uom_qty", "price_unit",
               "price_subtotal", "price_total", "discount", "product_uom_id",
               "qty_delivered", "qty_invoiced"],
      order: "id asc",
      limit: 0,
    });
  },

  // ── Inventory requirement report ─────────────────────────────────────────

  async getOrderLinesForInventory(dateFrom: string, dateTo: string) {
    return execute<{ product_id: [number, string]; product_uom_qty: number }[]>(
      "sale.order.line", "search_read",
      [[
        ["order_id.website_id", "=", WEBSITE_ID],
        ["order_id.state",      "in", ["sale", "done"]],
        ["order_id.date_order", ">=", dateFrom],
        ["order_id.date_order", "<=", dateTo],
        ["product_uom_qty",     ">",  0],
      ]],
      { fields: ["product_id", "product_uom_qty"], limit: 0 }
    );
  },

  async getProductVariants(productIds: number[]) {
    if (!productIds.length) return [];
    return execute<{ id: number; product_tmpl_id: [number, string]; product_template_attribute_value_ids: number[] }[]>(
      "product.product", "search_read",
      [[["id", "in", productIds]]],
      { fields: ["id", "product_tmpl_id", "product_template_attribute_value_ids"], limit: 0 }
    );
  },

  async getPackSizeValues(attrValueIds: number[]) {
    if (!attrValueIds.length) return [];
    return execute<{ id: number; name: string; product_tmpl_id: [number, string] }[]>(
      "product.template.attribute.value", "search_read",
      [[["id", "in", attrValueIds], ["attribute_id.name", "=", "Pack Size"]]],
      { fields: ["id", "name", "product_tmpl_id"], limit: 0 }
    );
  },

  async getProductTemplatesWithCategories(templateIds: number[]) {
    if (!templateIds.length) return [];
    return execute<{ id: number; name: string; public_categ_ids: number[] }[]>(
      "product.template", "search_read",
      [[["id", "in", templateIds]]],
      { fields: ["id", "name", "public_categ_ids"], limit: 0 }
    );
  },

  async getPublicCategories() {
    return execute<{ id: number; name: string }[]>(
      "product.public.category", "search_read",
      [[]],
      { fields: ["id", "name"], limit: 0 }
    );
  },

  async getOrderLinesWithRevenue(dateFrom: string, dateTo: string) {
    return execute<{ product_id: [number, string]; product_uom_qty: number; price_subtotal: number }[]>(
      "sale.order.line", "search_read",
      [[
        ["order_id.website_id", "=", WEBSITE_ID],
        ["order_id.state",      "in", ["sale", "done"]],
        ["order_id.date_order", ">=", dateFrom],
        ["order_id.date_order", "<=", dateTo],
        ["product_uom_qty",     ">",  0],
      ]],
      { fields: ["product_id", "product_uom_qty", "price_subtotal"], limit: 0 }
    );
  },

  async getPOSOrderLinesInPeriod(dateFrom: string, dateTo: string) {
    return execute<{ product_id: [number, string] | false; qty: number; price_subtotal: number }[]>(
      "pos.order.line", "search_read",
      [[
        ["order_id.state",      "in", ["paid", "done", "invoiced"]],
        ["order_id.date_order", ">=", dateFrom],
        ["order_id.date_order", "<=", dateTo],
      ]],
      { fields: ["product_id", "qty", "price_subtotal"], limit: 0 }
    );
  },

  async getPartnerContact(partnerId: number): Promise<{ phone: string | false; email: string | false } | null> {
    if (!partnerId) return null;
    const result = await execute<{ phone: string | false; email: string | false }[]>(
      "res.partner", "read", [[partnerId]],
      { fields: ["phone", "email"] }
    );
    return result?.[0] ?? null;
  },

  async getPartnerAddress(partnerId: number): Promise<{
    id: number;
    street: string | false;
    street2: string | false;
    city: string | false;
    zip: string | false;
    state_id: [number, string] | false;
    country_id: [number, string] | false;
  } | null> {
    if (!partnerId) return null;
    const result = await execute<{ id: number; street: string | false; street2: string | false; city: string | false; zip: string | false; state_id: [number, string] | false; country_id: [number, string] | false }[]>(
      "res.partner", "read", [[partnerId]],
      { fields: ["id", "street", "street2", "city", "zip", "state_id", "country_id"] }
    );
    return result?.[0] ?? null;
  },

  async getPickingsByOrder(orderId: number) {
    return execute<{
      id: number;
      name: string;
      state: string;
      scheduled_date: string | false;
      date_done: string | false;
      partner_id: [number, string] | false;
    }[]>("stock.picking", "search_read", [
      [["sale_id", "=", orderId], ["picking_type_code", "=", "outgoing"]],
    ], {
      fields: ["id", "name", "state", "scheduled_date", "date_done", "partner_id"],
      limit: 0,
    });
  },
};
