import { odoo } from "@/lib/odoo";
import { format, eachDayOfInterval, parseISO } from "date-fns";

// ── Shared constants (single source of truth) ────────────────────────────────
export const WEB_CONFIRMED  = ["sale", "done"];
export const POS_CONFIRMED  = ["paid", "done", "invoiced"];

// ── Unified order shape for the orders table ─────────────────────────────────
export type UnifiedOrder = {
  id: number;
  name: string;
  state: string;
  date_order: string;
  amount_total: number;
  amount_delivery: number;
  partner_id: [number, string];
  invoice_status: string;
  delivery_status: string | false;
  source: "website" | "pos";
};

export async function fetchDashboardFromOdoo(from: string, to: string) {

  // ── 4 Odoo calls in parallel ──────────────────────────────────────────────
  const [orders, pickings, visitors, posOrders] = await Promise.all([
    odoo.getOrdersInPeriod(from, to),       // sale.order (all states in period)
    odoo.getPickingsInPeriod(from, to),     // stock.picking (scheduled in period)
    odoo.getVisitors(from, to),             // website.visitor count
    odoo.getPOSOrdersInPeriod(from, to),    // pos.order (non-cancelled in period)
  ]);

  // ── Website subsets ───────────────────────────────────────────────────────
  const webConfirmed = orders.filter((o) => WEB_CONFIRMED.includes(o.state));
  const webCarts     = orders.filter((o) => o.state === "draft" && (o.cart_quantity ?? 0) > 0);
  const webCancelled = orders.filter((o) => o.state === "cancel");

  // ── POS subsets — only confirmed (paid/done/invoiced) shown in table ──────
  // POS "draft" = open terminal session, not useful for analytics
  const posConfirmed = posOrders.filter((o) => POS_CONFIRMED.includes(o.state));

  // ── Logistics ────────────────────────────────────────────────────────────
  // Both counts are for pickings SCHEDULED in the date range
  const pendingCount    = pickings.filter((p) => ["confirmed", "assigned", "waiting"].includes(p.state)).length;
  const dispatchedCount = pickings.filter((p) => p.state === "done").length;

  // ── Partner ID lists (walk-in POS orders = partner_id false, excluded) ────
  const webPartnerIds = [...new Set(webConfirmed.map((o) => o.partner_id[0]))];
  const posPartnerIds = [...new Set(
    posConfirmed
      .filter((o) => Array.isArray(o.partner_id))
      .map((o) => (o.partner_id as [number, string])[0])
  )];
  // All unique known customers across both channels
  const allPartnerIds = [...new Set([...webPartnerIds, ...posPartnerIds])];

  // ── New vs repeat classification ──────────────────────────────────────────
  // Fetch BOTH website and POS all-time history in parallel (1 extra call each)
  // POS history is needed so in-store-only customers aren't always "new"
  const [saleHistory, posHistory] = await Promise.all([
    allPartnerIds.length  > 0 ? odoo.getOrderHistoryForPartners(allPartnerIds)    : Promise.resolve([]),
    posPartnerIds.length  > 0 ? odoo.getPOSOrderHistoryForPartners(posPartnerIds) : Promise.resolve([]),
  ]);

  // Build firstOrder map: earliest confirmed order date across BOTH channels
  const firstOrder: Record<number, string> = {};
  const updateFirst = (pid: number, date: string) => {
    if (!firstOrder[pid] || date < firstOrder[pid]) firstOrder[pid] = date;
  };
  for (const o of saleHistory) updateFirst(o.partner_id[0], o.date_order);
  for (const o of posHistory)  {
    if (Array.isArray(o.partner_id)) updateFirst(o.partner_id[0], o.date_order);
  }

  const periodStart = `${from} 00:00:00`;
  const isRepeat = (pid: number) => !!(firstOrder[pid] && firstOrder[pid] < periodStart);

  // Per-channel and combined new/repeat counts
  let webNew = 0, webRepeat = 0;
  for (const pid of webPartnerIds) isRepeat(pid) ? webRepeat++ : webNew++;

  let posNew = 0, posRepeat = 0;
  for (const pid of posPartnerIds) isRepeat(pid) ? posRepeat++ : posNew++;

  let combinedNew = 0, combinedRepeat = 0;
  for (const pid of allPartnerIds) isRepeat(pid) ? combinedRepeat++ : combinedNew++;
  // Invariant: combinedNew + combinedRepeat === allPartnerIds.length ✓

  // ── Website KPIs ──────────────────────────────────────────────────────────
  const webRevenue   = webConfirmed.reduce((s, o) => s + o.amount_total, 0);
  const webDelivery  = webConfirmed.reduce((s, o) => s + o.amount_delivery, 0);
  const webCount     = webConfirmed.length;
  const webAOV       = webCount > 0 ? webRevenue / webCount : 0;
  const cartValue    = webCarts.reduce((s, o) => s + o.amount_total, 0);

  // ── POS KPIs ──────────────────────────────────────────────────────────────
  const posRevenue   = posConfirmed.reduce((s, o) => s + o.amount_total, 0);
  const posCount     = posConfirmed.length;
  const posAOV       = posCount > 0 ? posRevenue / posCount : 0;
  const walkInCount  = posOrders.filter((o) => !Array.isArray(o.partner_id) && POS_CONFIRMED.includes(o.state)).length;

  // ── Combined KPIs ─────────────────────────────────────────────────────────
  const combinedRevenue = webRevenue + posRevenue;
  const combinedCount   = webCount + posCount;
  const combinedAOV     = combinedCount > 0 ? combinedRevenue / combinedCount : 0;

  // ── Sales trend (per-day, confirmed orders only for both channels) ─────────
  const days = eachDayOfInterval({ start: parseISO(from), end: parseISO(to) });
  const dailyMap: Record<string, { revenue: number; orders: number; posRevenue: number; posOrders: number }> = {};
  for (const d of days) dailyMap[format(d, "yyyy-MM-dd")] = { revenue: 0, orders: 0, posRevenue: 0, posOrders: 0 };
  for (const o of webConfirmed) {
    const day = o.date_order.slice(0, 10);
    if (dailyMap[day]) { dailyMap[day].revenue += o.amount_total; dailyMap[day].orders++; }
  }
  for (const o of posConfirmed) {
    const day = o.date_order.slice(0, 10);
    if (dailyMap[day]) { dailyMap[day].posRevenue += o.amount_total; dailyMap[day].posOrders++; }
  }
  const trend = Object.entries(dailyMap).map(([date, v]) => ({
    date,
    label:      format(parseISO(date), "MMM d"),
    revenue:    Math.round(v.revenue),
    orders:     v.orders,
    posRevenue: Math.round(v.posRevenue),
    posOrders:  v.posOrders,
  }));

  // ── Normalize orders for the table ───────────────────────────────────────
  // Website: include all states (confirmed, carts, cancelled) — table has tab filters
  const unifiedWebOrders: UnifiedOrder[] = orders.map((o) => ({
    ...o,
    source: "website" as const,
  }));
  // POS: only confirmed orders (paid/done/invoiced) — drafts are open terminal sessions
  const unifiedPosOrders: UnifiedOrder[] = posConfirmed.map((o) => ({
    id:              o.id,
    name:            o.name,
    state:           o.state,
    date_order:      o.date_order,
    amount_total:    o.amount_total,
    amount_delivery: 0,
    partner_id:      Array.isArray(o.partner_id) ? o.partner_id : [0, "Walk-in Customer"],
    invoice_status:  "pos",
    delivery_status: false,
    source:          "pos" as const,
  }));

  const allOrders = [...unifiedWebOrders, ...unifiedPosOrders]
    .sort((a, b) => b.date_order.localeCompare(a.date_order));

  return {
    kpis: {
      // Combined (All channels)
      combined: {
        totalRevenue:    combinedRevenue,
        orderCount:      combinedCount,
        avgOrderValue:   combinedAOV,
        totalCustomers:  allPartnerIds.length,
        newCustomers:    combinedNew,
        repeatCustomers: combinedRepeat,
        totalDeliveryFund: webDelivery,
      },
      // Website only
      website: {
        visitors:         visitors,
        cartAdds:         webCarts.length,
        cartValue,
        orderCount:       webCount,
        avgOrderValue:    webAOV,
        newCustomers:     webNew,
        repeatCustomers:  webRepeat,
        totalRevenue:     webRevenue,
        totalCustomers:   webPartnerIds.length,
        totalDeliveryFund: webDelivery,
      },
      // POS only
      pos: {
        totalRevenue:    posRevenue,
        orderCount:      posCount,
        avgOrderValue:   posAOV,
        newCustomers:    posNew,
        repeatCustomers: posRepeat,
        totalCustomers:  posPartnerIds.length,
        walkInOrders:    walkInCount,
      },
      // Logistics (website delivery only)
      logistics: {
        dispatched: dispatchedCount,
        pending:    pendingCount,
      },
    },
    trend,
    orders: allOrders,
  };
}
