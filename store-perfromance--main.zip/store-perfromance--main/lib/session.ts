import { SignJWT, jwtVerify, type JWTPayload } from "jose";

const SECRET = new TextEncoder().encode(
  process.env.JWT_SECRET ?? "uc-dashboard-dev-secret-change-in-prod"
);
const ALGORITHM  = "HS256";
const EXPIRES_IN = "30d";

export const SESSION_COOKIE = "uc_session";

export type UserRole = "store_admin" | "store_manager";

export interface SessionPayload extends JWTPayload {
  sub: string;   // MongoDB _id as string
  email: string;
  name: string;
  role: UserRole;
}

export async function createSessionToken(payload: Omit<SessionPayload, "iat" | "exp">): Promise<string> {
  return new SignJWT(payload as JWTPayload)
    .setProtectedHeader({ alg: ALGORITHM })
    .setIssuedAt()
    .setExpirationTime(EXPIRES_IN)
    .sign(SECRET);
}

export async function verifySessionToken(token: string): Promise<SessionPayload | null> {
  try {
    const { payload } = await jwtVerify(token, SECRET);
    return payload as SessionPayload;
  } catch {
    return null;
  }
}
