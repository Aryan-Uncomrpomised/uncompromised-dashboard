import { MongoClient, Db, Collection, Document } from "mongodb";

const MONGO_URL = process.env.MONGO_URL!;
const DB_NAME   = "uc_dashboard";

if (!MONGO_URL) throw new Error("MONGO_URL is not set");

// Reuse connection across hot-reloads in dev; in prod Vercel reuses warm instances
declare global {
  // eslint-disable-next-line no-var
  var _mongoClient: MongoClient | undefined;
}

let client: MongoClient;

// Node 22+ has stricter TLS — use tlsAllowInvalidCertificates only in dev
const clientOptions = process.env.NODE_ENV === "development"
  ? { tls: true, tlsAllowInvalidCertificates: true }
  : { tls: true };

if (process.env.NODE_ENV === "development") {
  if (!globalThis._mongoClient) {
    globalThis._mongoClient = new MongoClient(MONGO_URL, clientOptions);
  }
  client = globalThis._mongoClient;
} else {
  client = new MongoClient(MONGO_URL, clientOptions);
}

let connected = false;

async function connect() {
  if (!connected) {
    await client.connect();
    // Create indexes once
    const db = client.db(DB_NAME);
    await Promise.all([
      db.collection("users").createIndex({ email: 1 }, { unique: true }),
      db.collection("order_cache").createIndex({ odooId: 1 }, { unique: true }),
      // No TTL on order_cache — order details (lines, price, address) are permanent
      db.collection("order_acknowledgements").createIndex({ odooId: 1 }, { unique: true }),
    ]).catch(() => {}); // ignore if indexes already exist
    connected = true;
  }
}

export async function getDb(): Promise<Db> {
  await connect();
  return client.db(DB_NAME);
}

export async function getCollection<T extends Document>(name: string): Promise<Collection<T>> {
  const db = await getDb();
  return db.collection<T>(name);
}

// Batch fetch the latest internal status for a list of order IDs
// Returns a map of odooId → latest status step
export async function getOrderStatusMap(odooIds: number[]): Promise<Record<number, string>> {
  if (!odooIds.length) return {};
  const col = await getCollection<{ odooId: number; timeline: { status: string }[] }>("order_status");
  const docs = await col.find({ odooId: { $in: odooIds } }, { projection: { odooId: 1, timeline: 1 } }).toArray();
  const priority = ["shipped", "packed", "acknowledged"];
  const result: Record<number, string> = {};
  for (const doc of docs) {
    for (const step of priority) {
      if (doc.timeline?.some((e) => e.status === step)) {
        result[doc.odooId] = step;
        break;
      }
    }
  }
  return result;
}

// Health check — returns true if connection is alive
export async function pingMongo(): Promise<boolean> {
  try {
    await connect();
    await client.db("admin").command({ ping: 1 });
    return true;
  } catch {
    return false;
  }
}
