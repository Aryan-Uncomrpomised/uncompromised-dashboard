const BASE = "https://apiv2.shiprocket.in/v1/external";

// Cache token in module scope — Shiprocket tokens expire in 10 days
let _token: string | null = null;
let _tokenFetched = 0;
const TOKEN_TTL_MS = 9 * 24 * 60 * 60 * 1000; // refresh every 9 days

async function getToken(): Promise<string> {
  const apiKey = process.env.SHIP_ROCKET_API_KEY!;
  if (!apiKey) throw new Error("SHIP_ROCKET_API_KEY is not set");

  // If API key looks like a JWT (starts with eyJ) use it directly
  if (apiKey.startsWith("eyJ")) return apiKey;

  // Otherwise it's email:password format or a raw token — try as Bearer directly first
  // If Shiprocket rejects, add SHIP_ROCKET_EMAIL + use apiKey as password
  if (_token && Date.now() - _tokenFetched < TOKEN_TTL_MS) return _token;

  const email = process.env.SHIP_ROCKET_EMAIL;
  if (email) {
    // Authenticate with email + password
    const res = await fetch(`${BASE}/auth/login`, {
      method:  "POST",
      headers: { "Content-Type": "application/json" },
      body:    JSON.stringify({ email, password: apiKey }),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(`Shiprocket auth failed: ${data.message || JSON.stringify(data)}`);
    _token = data.token;
    _tokenFetched = Date.now();
    return _token!;
  }

  // Use API key directly as Bearer token (Shiprocket panel-generated tokens)
  return apiKey;
}

export interface ShiprocketOrderItem {
  name:          string;
  sku:           string;
  units:         number;
  selling_price: number;
}

export interface ShiprocketOrderPayload {
  order_id:               string;
  order_date:             string;
  pickup_location:        string;
  billing_customer_name:  string;
  billing_last_name:      string;
  billing_address:        string;
  billing_address_2:      string;
  billing_city:           string;
  billing_pincode:        string;
  billing_state:          string;
  billing_country:        string;
  billing_email:          string;
  billing_phone:          string;
  shipping_is_billing:    boolean;
  payment_method:         string;
  sub_total:              number;
  length:                 number;
  width:                  number;
  height:                 number;
  weight:                 number;
  order_items:            ShiprocketOrderItem[];
}

export async function createShiprocketOrder(payload: ShiprocketOrderPayload) {
  const token = await getToken();
  const res   = await fetch(`${BASE}/orders/create/adhoc`, {
    method:  "POST",
    headers: { "Content-Type": "application/json", "Authorization": `Bearer ${token}` },
    body:    JSON.stringify(payload),
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.message || JSON.stringify(data));
  return data as { order_id: number; shipment_id: number; status: string; channel_order_id: string };
}
