import { ObjectId } from "mongodb";
import bcrypt from "bcryptjs";
import { getCollection } from "./mongo";
import type { UserRole } from "./session";

export interface DbUser {
  _id: ObjectId;
  email: string;
  username?: string;
  name: string;
  role: UserRole;
  passwordHash: string;
  createdAt: Date;
  lastLoginAt?: Date;
}

export type SafeUser = Omit<DbUser, "passwordHash">;

const col = () => getCollection<DbUser>("users");

// Supports login by email OR username
export async function findByEmailOrUsername(identifier: string): Promise<DbUser | null> {
  const val = identifier.toLowerCase().trim();
  return (await col()).findOne({ $or: [{ email: val }, { username: val }] });
}

export async function createUser(data: {
  email: string;
  name: string;
  password: string;
  role: UserRole;
}): Promise<SafeUser> {
  const passwordHash = await bcrypt.hash(data.password, 12);
  const doc: Omit<DbUser, "_id"> = {
    email:        data.email.toLowerCase().trim(),
    name:         data.name.trim(),
    role:         data.role,
    passwordHash,
    createdAt:    new Date(),
  };
  const result = await (await col()).insertOne(doc as DbUser);
  const { passwordHash: _, ...safe } = { ...doc, _id: result.insertedId };
  return safe as SafeUser;
}

export async function verifyPassword(user: DbUser, password: string): Promise<boolean> {
  return bcrypt.compare(password, user.passwordHash);
}

export async function listUsers(): Promise<SafeUser[]> {
  return (await col())
    .find({}, { projection: { passwordHash: 0 } })
    .sort({ createdAt: -1 })
    .toArray() as Promise<SafeUser[]>;
}

export async function countUsers(): Promise<number> {
  return (await col()).countDocuments();
}

export async function touchLastLogin(id: string): Promise<void> {
  await (await col()).updateOne(
    { _id: new ObjectId(id) },
    { $set: { lastLoginAt: new Date() } }
  );
}

export async function deleteUser(id: string): Promise<void> {
  await (await col()).deleteOne({ _id: new ObjectId(id) });
}
