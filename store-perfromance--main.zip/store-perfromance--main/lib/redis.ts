import Redis from "ioredis";

declare global {
  // eslint-disable-next-line no-var
  var _redis: Redis | undefined;
}

function createClient() {
  const url = process.env.REDIS_URL;
  if (!url) throw new Error("REDIS_URL is not set");
  const client = new Redis(url, { maxRetriesPerRequest: 2, lazyConnect: false });
  client.on("error", (err) => console.error("[redis]", err.message));
  return client;
}

// Reuse connection across hot-reloads in dev
export const redis: Redis =
  globalThis._redis ?? (globalThis._redis = createClient());

const TTL = 60 * 10; // 10 minutes

export async function getCache<T>(key: string): Promise<T | null> {
  try {
    const raw = await redis.get(key);
    return raw ? (JSON.parse(raw) as T) : null;
  } catch {
    return null;
  }
}

export async function setCache(key: string, value: unknown): Promise<void> {
  try {
    await redis.set(key, JSON.stringify(value), "EX", TTL);
  } catch {
    // cache write failure is non-fatal
  }
}

// v2: cache key bumped after kpis.store → kpis.combined restructure
export function dashboardKey(from: string, to: string) {
  return `dashboard:v2:${from}:${to}`;
}

// Lightweight manager key — stores orders only (no KPIs, no charts)
export function managerDashboardKey(from: string, to: string) {
  return `dashboard:v2:manager:${from}:${to}`;
}

const LAST_REFRESH_KEY = "cron:last_refresh";

export async function setLastRefresh(): Promise<void> {
  try {
    await redis.set(LAST_REFRESH_KEY, Math.floor(Date.now() / 1000));
  } catch {
    // non-fatal
  }
}

export async function getLastRefresh(): Promise<number | null> {
  try {
    const val = await redis.get(LAST_REFRESH_KEY);
    return val ? parseInt(val, 10) : null;
  } catch {
    return null;
  }
}
