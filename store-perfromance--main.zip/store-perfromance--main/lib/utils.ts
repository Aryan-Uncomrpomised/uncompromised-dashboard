import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatINR(amount: number): string {
  return new Intl.NumberFormat("en-IN", {
    style: "currency",
    currency: "INR",
    maximumFractionDigits: 0,
  }).format(amount);
}

export function formatNumber(n: number): string {
  return new Intl.NumberFormat("en-IN").format(n);
}

// Odoo stores dates in UTC with no timezone indicator ("2026-06-01 18:03:43")
// Appending Z tells date-fns it's UTC → converts to browser local time (IST in India)
export function parseOdooDate(dateStr: string): Date {
  return new Date(dateStr.replace(" ", "T") + "Z");
}
