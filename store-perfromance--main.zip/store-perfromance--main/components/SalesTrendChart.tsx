"use client";

import {
  AreaChart, Area, XAxis, YAxis, CartesianGrid,
  Tooltip, ResponsiveContainer, Legend,
} from "recharts";
import { formatINR } from "@/lib/utils";

interface TrendPoint {
  date: string;
  label: string;
  revenue: number;
  orders: number;
  posRevenue?: number;
  posOrders?: number;
}

type Source = "all" | "website" | "pos";

interface Props {
  data: TrendPoint[];
  source?: Source;
  loading?: boolean;
}

const CustomTooltip = ({ active, payload, label }: {
  active?: boolean;
  payload?: { name: string; value: number; color: string }[];
  label?: string;
}) => {
  if (!active || !payload?.length) return null;
  return (
    <div className="bg-white border border-slate-200 rounded-xl shadow-lg px-4 py-3 text-sm min-w-[160px]">
      <p className="font-semibold text-slate-700 mb-2">{label}</p>
      {payload.map((p) => {
        const isRevenue = p.name.includes("revenue") || p.name.includes("Revenue");
        return (
          <div key={p.name} className="flex items-center justify-between gap-4 text-slate-600">
            <span className="flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full inline-block" style={{ background: p.color }} />
              {p.name === "revenue" ? "Web Revenue" :
               p.name === "posRevenue" ? "POS Revenue" :
               p.name === "orders" ? "Web Orders" : "POS Orders"}
            </span>
            <span className="font-medium text-slate-900">
              {isRevenue ? formatINR(p.value) : p.value}
            </span>
          </div>
        );
      })}
    </div>
  );
};

export function SalesTrendChart({ data, source = "all", loading }: Props) {
  if (loading) return <div className="h-64 bg-slate-50 animate-pulse rounded-2xl" />;

  const showWeb = source === "all" || source === "website";
  const showPOS = source === "all" || source === "pos";
  const hasPOS  = data.some((d) => (d.posRevenue ?? 0) > 0 || (d.posOrders ?? 0) > 0);

  return (
    <ResponsiveContainer width="100%" height={260}>
      <AreaChart data={data} margin={{ top: 5, right: 10, left: 0, bottom: 5 }}>
        <defs>
          <linearGradient id="revGrad"    x1="0" y1="0" x2="0" y2="1">
            <stop offset="5%"  stopColor="#16a34a" stopOpacity={0.15} />
            <stop offset="95%" stopColor="#16a34a" stopOpacity={0} />
          </linearGradient>
          <linearGradient id="posRevGrad" x1="0" y1="0" x2="0" y2="1">
            <stop offset="5%"  stopColor="#f97316" stopOpacity={0.15} />
            <stop offset="95%" stopColor="#f97316" stopOpacity={0} />
          </linearGradient>
          <linearGradient id="ordGrad"    x1="0" y1="0" x2="0" y2="1">
            <stop offset="5%"  stopColor="#3b82f6" stopOpacity={0.12} />
            <stop offset="95%" stopColor="#3b82f6" stopOpacity={0} />
          </linearGradient>
          <linearGradient id="posOrdGrad" x1="0" y1="0" x2="0" y2="1">
            <stop offset="5%"  stopColor="#a855f7" stopOpacity={0.12} />
            <stop offset="95%" stopColor="#a855f7" stopOpacity={0} />
          </linearGradient>
        </defs>

        <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false} />
        <XAxis dataKey="label" tick={{ fontSize: 12, fill: "#94a3b8" }} axisLine={false} tickLine={false} />
        <YAxis yAxisId="rev" orientation="left"  tick={{ fontSize: 11, fill: "#94a3b8" }} axisLine={false} tickLine={false}
          tickFormatter={(v) => `₹${v >= 1000 ? `${(v / 1000).toFixed(0)}k` : v}`} />
        <YAxis yAxisId="ord" orientation="right" tick={{ fontSize: 11, fill: "#94a3b8" }} axisLine={false} tickLine={false} />
        <Tooltip content={<CustomTooltip />} />
        <Legend iconType="circle" iconSize={8} wrapperStyle={{ fontSize: 12, paddingTop: 8 }}
          formatter={(v) =>
            v === "revenue"    ? "Web Revenue" :
            v === "posRevenue" ? "POS Revenue" :
            v === "orders"     ? "Web Orders"  : "POS Orders"
          }
        />

        {showWeb && (
          <Area yAxisId="rev" type="monotone" dataKey="revenue"
            stroke="#16a34a" strokeWidth={2} fill="url(#revGrad)" dot={false} activeDot={{ r: 5 }} />
        )}
        {showWeb && (
          <Area yAxisId="ord" type="monotone" dataKey="orders"
            stroke="#3b82f6" strokeWidth={2} fill="url(#ordGrad)" dot={false} activeDot={{ r: 5 }} />
        )}
        {showPOS && hasPOS && (
          <Area yAxisId="rev" type="monotone" dataKey="posRevenue"
            stroke="#f97316" strokeWidth={2} fill="url(#posRevGrad)" dot={false} activeDot={{ r: 5 }} />
        )}
        {showPOS && hasPOS && (
          <Area yAxisId="ord" type="monotone" dataKey="posOrders"
            stroke="#a855f7" strokeWidth={2} fill="url(#posOrdGrad)" dot={false} activeDot={{ r: 5 }} />
        )}
      </AreaChart>
    </ResponsiveContainer>
  );
}
