"use client";

import {
  format, subDays, startOfMonth, endOfMonth, startOfYear,
  getYear, setMonth, setYear, parseISO,
} from "date-fns";
import { CalendarIcon, ChevronDown, ChevronLeft, ChevronRight } from "lucide-react";
import { useState, useRef, useEffect } from "react";

export type DateRange = { from: string; to: string; label: string };

type Tab = "quick" | "month" | "custom";

const MONTH_NAMES = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];

const QUICK_PRESETS: { label: string; get: () => DateRange }[] = [
  { label: "Today",       get: () => { const t = format(new Date(), "yyyy-MM-dd"); return { from: t, to: t, label: "Today" }; } },
  { label: "Yesterday",   get: () => { const t = format(subDays(new Date(), 1), "yyyy-MM-dd"); return { from: t, to: t, label: "Yesterday" }; } },
  { label: "Last 7 days", get: () => ({ from: format(subDays(new Date(), 6), "yyyy-MM-dd"), to: format(new Date(), "yyyy-MM-dd"), label: "Last 7 days" }) },
  { label: "Last 30 days",get: () => ({ from: format(subDays(new Date(), 29), "yyyy-MM-dd"), to: format(new Date(), "yyyy-MM-dd"), label: "Last 30 days" }) },
  { label: "This month",  get: () => ({ from: format(startOfMonth(new Date()), "yyyy-MM-dd"), to: format(new Date(), "yyyy-MM-dd"), label: "This month" }) },
  { label: "This year",   get: () => ({ from: format(startOfYear(new Date()), "yyyy-MM-dd"), to: format(new Date(), "yyyy-MM-dd"), label: "This year" }) },
];

interface Props {
  value: DateRange;
  onChange: (r: DateRange) => void;
}

export function DateRangePicker({ value, onChange }: Props) {
  const [open, setOpen] = useState(false);
  const [tab, setTab] = useState<Tab>("quick");
  const [monthYear, setMonthYear] = useState(getYear(new Date()));
  const [customFrom, setCustomFrom] = useState(value.from);
  const [customTo, setCustomTo] = useState(value.to);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, []);

  const close = () => setOpen(false);

  const applyCustom = () => {
    if (!customFrom || !customTo) return;
    const from = customFrom <= customTo ? customFrom : customTo;
    const to   = customFrom <= customTo ? customTo   : customFrom;
    onChange({ from, to, label: `${from} – ${to}` });
    close();
  };

  const selectMonth = (monthIndex: number) => {
    const d = setMonth(setYear(new Date(), monthYear), monthIndex);
    const from = format(startOfMonth(d), "yyyy-MM-dd");
    // if selected month is current or future, cap to today
    const end  = endOfMonth(d);
    const to   = end > new Date() ? format(new Date(), "yyyy-MM-dd") : format(end, "yyyy-MM-dd");
    onChange({ from, to, label: `${MONTH_NAMES[monthIndex]} ${monthYear}` });
    close();
  };

  const currentYear = getYear(new Date());

  return (
    <div className="relative" ref={ref}>
      <button
        onClick={() => setOpen((p) => !p)}
        className="flex items-center gap-2 px-4 py-2.5 bg-white border border-slate-200 rounded-xl text-sm font-medium text-slate-700 hover:bg-slate-50 hover:border-slate-300 transition-colors shadow-sm"
      >
        <CalendarIcon className="w-4 h-4 text-slate-400" />
        <span>{value.label}</span>
        <span className="text-slate-400 text-xs hidden sm:inline">
          {value.from === value.to ? value.from : `${value.from} – ${value.to}`}
        </span>
        <ChevronDown className="w-4 h-4 text-slate-400 ml-1" />
      </button>

      {open && (
        <div className="absolute right-0 top-full mt-2 w-72 bg-white border border-slate-200 rounded-2xl shadow-xl z-50 overflow-hidden">

          {/* Tabs */}
          <div className="flex border-b border-slate-100 p-1 gap-1">
            {(["quick", "month", "custom"] as Tab[]).map((t) => (
              <button
                key={t}
                onClick={() => setTab(t)}
                className={`flex-1 py-1.5 text-xs font-medium rounded-lg capitalize transition-colors ${
                  tab === t ? "bg-slate-900 text-white" : "text-slate-500 hover:bg-slate-50"
                }`}
              >
                {t}
              </button>
            ))}
          </div>

          {/* Quick presets */}
          {tab === "quick" && (
            <div className="py-2">
              {QUICK_PRESETS.map((p) => (
                <button
                  key={p.label}
                  onClick={() => { onChange(p.get()); close(); }}
                  className={`w-full text-left px-4 py-2.5 text-sm transition-colors ${
                    value.label === p.label ? "bg-brand-50 text-brand-700 font-semibold" : "text-slate-700 hover:bg-slate-50"
                  }`}
                >
                  {p.label}
                </button>
              ))}
            </div>
          )}

          {/* Month picker */}
          {tab === "month" && (
            <div className="p-3">
              {/* Year navigation */}
              <div className="flex items-center justify-between mb-3">
                <button
                  onClick={() => setMonthYear((y) => y - 1)}
                  disabled={monthYear <= 2020}
                  className="p-1 rounded-lg hover:bg-slate-100 disabled:opacity-30"
                >
                  <ChevronLeft className="w-4 h-4 text-slate-500" />
                </button>
                <span className="text-sm font-semibold text-slate-700">{monthYear}</span>
                <button
                  onClick={() => setMonthYear((y) => y + 1)}
                  disabled={monthYear >= currentYear}
                  className="p-1 rounded-lg hover:bg-slate-100 disabled:opacity-30"
                >
                  <ChevronRight className="w-4 h-4 text-slate-500" />
                </button>
              </div>
              {/* Month grid */}
              <div className="grid grid-cols-4 gap-1.5">
                {MONTH_NAMES.map((name, i) => {
                  const isSelected = value.label === `${name} ${monthYear}`;
                  const isFuture   = monthYear === currentYear && i > new Date().getMonth();
                  return (
                    <button
                      key={name}
                      onClick={() => !isFuture && selectMonth(i)}
                      disabled={isFuture}
                      className={`py-2 rounded-xl text-xs font-medium transition-colors ${
                        isSelected
                          ? "bg-brand-600 text-white"
                          : isFuture
                          ? "text-slate-300 cursor-not-allowed"
                          : "hover:bg-slate-100 text-slate-700"
                      }`}
                    >
                      {name}
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* Custom date range */}
          {tab === "custom" && (
            <div className="p-4 space-y-3">
              <div>
                <label className="block text-xs text-slate-400 mb-1">From</label>
                <input
                  type="date"
                  value={customFrom}
                  max={format(new Date(), "yyyy-MM-dd")}
                  onChange={(e) => setCustomFrom(e.target.value)}
                  className="w-full border border-slate-200 rounded-xl px-3 py-2 text-sm text-slate-700 focus:outline-none focus:ring-2 focus:ring-brand-500 focus:border-transparent"
                />
              </div>
              <div>
                <label className="block text-xs text-slate-400 mb-1">To</label>
                <input
                  type="date"
                  value={customTo}
                  max={format(new Date(), "yyyy-MM-dd")}
                  onChange={(e) => setCustomTo(e.target.value)}
                  className="w-full border border-slate-200 rounded-xl px-3 py-2 text-sm text-slate-700 focus:outline-none focus:ring-2 focus:ring-brand-500 focus:border-transparent"
                />
              </div>
              <button
                onClick={applyCustom}
                disabled={!customFrom || !customTo}
                className="w-full py-2 bg-brand-600 text-white rounded-xl text-sm font-medium hover:bg-brand-700 disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
              >
                Apply
              </button>
            </div>
          )}

        </div>
      )}
    </div>
  );
}
