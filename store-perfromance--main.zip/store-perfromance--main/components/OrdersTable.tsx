"use client";

import { useState, useEffect } from "react";
import { formatINR, parseOdooDate } from "@/lib/utils";
import { format } from "date-fns";
import { ChevronLeft, ChevronRight } from "lucide-react";

type Order = {
  id: number;
  name: string;
  state: string;
  date_order: string;
  amount_total: number;
  amount_delivery: number;
  partner_id: [number, string];
  invoice_status: string;
  delivery_status: string | false;
  source?: "website" | "pos";
};

interface Props {
  orders: Order[];
  orderStatuses?: Record<number, string>;
  onRowClick?: (order: Order) => void;
  loading?: boolean;
}

const PAGE_SIZE = 10;

// Odoo states
const ODOO_LABELS: Record<string, { label: string; cls: string }> = {
  draft:    { label: "Draft / Cart",   cls: "bg-slate-100 text-slate-600" },
  sent:     { label: "Quotation Sent", cls: "bg-yellow-50 text-yellow-700" },
  sale:     { label: "Confirmed",      cls: "bg-emerald-50 text-emerald-700" },
  done:     { label: "Done",           cls: "bg-blue-50 text-blue-700" },
  cancel:   { label: "Cancelled",      cls: "bg-red-50 text-red-600" },
  paid:     { label: "Paid",           cls: "bg-emerald-50 text-emerald-700" },
  invoiced: { label: "Invoiced",       cls: "bg-blue-50 text-blue-700" },
};

// Our internal status (overrides Odoo state for website confirmed orders)
const INTERNAL_LABELS: Record<string, { label: string; cls: string }> = {
  acknowledged: { label: "Acknowledged", cls: "bg-blue-100 text-blue-700" },
  packed:       { label: "Packed",       cls: "bg-amber-100 text-amber-700" },
  shipped:      { label: "Shipped",      cls: "bg-emerald-100 text-emerald-700" },
};

function Badge({ label, cls }: { label: string; cls: string }) {
  return (
    <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium ${cls}`}>
      {label}
    </span>
  );
}

export function OrdersTable({ orders, orderStatuses = {}, onRowClick, loading }: Props) {
  const [page, setPage] = useState(1);

  useEffect(() => { setPage(1); }, [orders]);

  if (loading) {
    return (
      <div className="space-y-2">
        {Array.from({ length: PAGE_SIZE }).map((_, i) => (
          <div key={i} className="h-10 bg-slate-100 animate-pulse rounded-lg" />
        ))}
      </div>
    );
  }

  if (!orders.length) {
    return <div className="py-12 text-center text-slate-400 text-sm">No orders in selected period</div>;
  }

  const totalPages = Math.ceil(orders.length / PAGE_SIZE);
  const pageOrders = orders.slice((page - 1) * PAGE_SIZE, page * PAGE_SIZE);

  return (
    <div>
      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="text-left text-xs text-slate-400 uppercase tracking-wider border-b border-slate-100">
              <th className="pb-3 pr-4 font-medium">Order</th>
              <th className="pb-3 pr-2 font-medium">Source</th>
              <th className="pb-3 pr-4 font-medium">Customer</th>
              <th className="pb-3 pr-4 font-medium">Date</th>
              <th className="pb-3 pr-4 font-medium text-right">Amount</th>
              <th className="pb-3 pr-4 font-medium text-right">Delivery</th>
              <th className="pb-3 font-medium">Status</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-50">
            {pageOrders.map((o) => {
              const isConfirmedWebsite = o.source === "website" && ["sale", "done"].includes(o.state);
              const internalStatus     = isConfirmedWebsite ? orderStatuses[o.id] : undefined;
              const isUnacknowledged   = isConfirmedWebsite && !internalStatus;

              // Status badge: internal overrides Odoo for confirmed website orders
              const badge = internalStatus
                ? INTERNAL_LABELS[internalStatus] ?? ODOO_LABELS[o.state]
                : ODOO_LABELS[o.state] ?? { label: o.state, cls: "bg-slate-100 text-slate-600" };

              return (
                <tr
                  key={o.id}
                  onClick={() => onRowClick?.(o)}
                  className={`transition-colors ${
                    isUnacknowledged
                      ? "bg-amber-50/60 hover:bg-amber-100/60"
                      : onRowClick
                      ? "hover:bg-brand-50"
                      : "hover:bg-slate-50"
                  } ${onRowClick ? "cursor-pointer" : ""}`}
                >
                  <td className="py-3 pr-4">
                    <div className="flex items-center gap-2">
                      <span className={`font-semibold text-slate-800 ${onRowClick ? "text-brand-700 hover:underline" : ""}`}>
                        {o.name}
                      </span>
                      {isUnacknowledged && (
                        <span className="inline-flex items-center px-1.5 py-0.5 rounded text-xs font-bold bg-red-500 text-white leading-none">
                          NEW
                        </span>
                      )}
                    </div>
                  </td>
                  <td className="py-3 pr-2">
                    {o.source === "pos"
                      ? <span className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-orange-50 text-orange-700">POS</span>
                      : <span className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-sky-50 text-sky-700">Web</span>
                    }
                  </td>
                  <td className="py-3 pr-4 text-slate-600 max-w-[160px] truncate">{o.partner_id[1]}</td>
                  <td className="py-3 pr-4 text-slate-500 whitespace-nowrap">
                    {format(parseOdooDate(o.date_order), "dd MMM, HH:mm")}
                  </td>
                  <td className="py-3 pr-4 text-right font-semibold text-slate-900">{formatINR(o.amount_total)}</td>
                  <td className="py-3 pr-4 text-right text-slate-500">
                    {o.amount_delivery > 0 ? formatINR(o.amount_delivery) : "—"}
                  </td>
                  <td className="py-3">
                    <Badge label={badge.label} cls={badge.cls} />
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {/* Pagination */}
      {totalPages > 1 && (
        <div className="flex items-center justify-between mt-4 pt-4 border-t border-slate-100">
          <span className="text-xs text-slate-400">
            {(page - 1) * PAGE_SIZE + 1}–{Math.min(page * PAGE_SIZE, orders.length)} of {orders.length} orders
          </span>
          <div className="flex items-center gap-1">
            <button
              onClick={() => setPage((p) => Math.max(1, p - 1))}
              disabled={page === 1}
              className="p-1.5 rounded-lg hover:bg-slate-100 disabled:opacity-30 disabled:cursor-not-allowed transition-colors"
            >
              <ChevronLeft className="w-4 h-4 text-slate-600" />
            </button>
            {Array.from({ length: totalPages }, (_, i) => i + 1)
              .filter((p) => p === 1 || p === totalPages || Math.abs(p - page) <= 1)
              .reduce<(number | "…")[]>((acc, p, i, arr) => {
                if (i > 0 && (p as number) - (arr[i - 1] as number) > 1) acc.push("…");
                acc.push(p);
                return acc;
              }, [])
              .map((p, i) =>
                p === "…" ? (
                  <span key={`ellipsis-${i}`} className="px-2 text-slate-300 text-sm">…</span>
                ) : (
                  <button
                    key={p}
                    onClick={() => setPage(p as number)}
                    className={`w-8 h-8 rounded-lg text-sm font-medium transition-colors ${
                      page === p ? "bg-brand-600 text-white" : "hover:bg-slate-100 text-slate-600"
                    }`}
                  >
                    {p}
                  </button>
                )
              )}
            <button
              onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
              disabled={page === totalPages}
              className="p-1.5 rounded-lg hover:bg-slate-100 disabled:opacity-30 disabled:cursor-not-allowed transition-colors"
            >
              <ChevronRight className="w-4 h-4 text-slate-600" />
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
