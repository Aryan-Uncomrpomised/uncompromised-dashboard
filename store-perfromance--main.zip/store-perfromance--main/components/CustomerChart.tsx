"use client";

import { PieChart, Pie, Cell, Tooltip, ResponsiveContainer, Legend } from "recharts";

interface Props {
  newCustomers: number;
  repeatCustomers: number;
  loading?: boolean;
}

const COLORS = ["#16a34a", "#3b82f6"];

export function CustomerChart({ newCustomers, repeatCustomers, loading }: Props) {
  if (loading) return <div className="h-48 bg-slate-50 animate-pulse rounded-2xl" />;

  const total = newCustomers + repeatCustomers;
  const data = [
    { name: "New", value: newCustomers },
    { name: "Repeat", value: repeatCustomers },
  ].filter((d) => d.value > 0);

  if (total === 0) {
    return (
      <div className="h-48 flex items-center justify-center text-slate-400 text-sm">
        No customer data
      </div>
    );
  }

  return (
    <ResponsiveContainer width="100%" height={200}>
      <PieChart>
        <Pie data={data} cx="50%" cy="50%" innerRadius={55} outerRadius={80} paddingAngle={3} dataKey="value">
          {data.map((_, i) => (
            <Cell key={i} fill={COLORS[i % COLORS.length]} />
          ))}
        </Pie>
        <Tooltip
          formatter={(v, name) => [`${v} (${total > 0 ? Math.round((Number(v) / total) * 100) : 0}%)`, name]}
          contentStyle={{ borderRadius: 12, border: "1px solid #e2e8f0", fontSize: 13 }}
        />
        <Legend iconType="circle" iconSize={8} wrapperStyle={{ fontSize: 12 }} />
      </PieChart>
    </ResponsiveContainer>
  );
}
