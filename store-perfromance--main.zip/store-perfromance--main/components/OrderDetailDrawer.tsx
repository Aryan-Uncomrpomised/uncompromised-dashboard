"use client";

import { useEffect, useState, useCallback } from "react";
import { format } from "date-fns";
import { parseOdooDate } from "@/lib/utils";
import {
  X, Package, Truck, CreditCard, User, MapPin, Hash, ChevronRight,
  CheckCircle2, Circle, Clock, BoxSelect,
} from "lucide-react";
import { formatINR } from "@/lib/utils";

// ── Types ─────────────────────────────────────────────────────────────────────
type OrderLine = {
  id: number;
  product_id: [number, string] | false;
  name: string;
  product_uom_qty: number;
  price_unit: number;
  price_subtotal: number;
  price_total: number;
  discount: number;
  product_uom_id: [number, string] | false;
  qty_delivered: number;
  qty_invoiced: number;
};

type Picking = {
  id: number;
  name: string;
  state: string;
  scheduled_date: string | false;
  date_done: string | false;
  partner_id: [number, string] | false;
};

type OrderDetail = {
  id: number;
  name: string;
  state: string;
  date_order: string;
  amount_total: number;
  amount_untaxed: number;
  amount_tax: number;
  amount_delivery: number;
  partner_id: [number, string];
  partner_shipping_id: [number, string] | false;
  invoice_status: string;
  delivery_status: string | false;
  note: string | false;
  carrier_id: [number, string] | false;
};

type StatusStep = "acknowledged" | "packed" | "shipped";

type TimelineEvent = {
  status: StatusStep;
  by: { id: string; name: string; email: string };
  at: string;
  note: string;
};

type ShippingAddress = {
  city:       string | false;
  state_id:   [number, string] | false;
  street:     string | false;
  street2:    string | false;
  zip:        string | false;
  country_id: [number, string] | false;
} | null;

type OrderStatus = {
  odooId: number;
  orderName: string;
  timeline: TimelineEvent[];
  updatedAt: string;
} | null;

interface Props {
  orderId: number | null;
  orderName?: string;
  onClose: () => void;
  canAct?: boolean; // true = store_manager (can mark steps); false/undefined = admin (view only)
}

// ── Badge / label maps ─────────────────────────────────────────────────────────
const STATE_STYLE: Record<string, string> = {
  draft:  "bg-slate-100 text-slate-600",
  sale:   "bg-emerald-50 text-emerald-700",
  done:   "bg-blue-50 text-blue-700",
  cancel: "bg-red-50 text-red-600",
};
const STATE_LABEL: Record<string, string> = {
  draft: "Draft / Cart", sale: "Confirmed", done: "Done", cancel: "Cancelled",
};
const DELIVERY_STYLE: Record<string, string> = {
  pending: "bg-orange-50 text-orange-600",
  partial: "bg-yellow-50 text-yellow-700",
  full:    "bg-emerald-50 text-emerald-700",
};
const PICKING_STYLE: Record<string, string> = {
  draft: "bg-slate-100 text-slate-500", confirmed: "bg-orange-50 text-orange-600",
  assigned: "bg-yellow-50 text-yellow-700", done: "bg-emerald-50 text-emerald-700",
  cancel: "bg-red-50 text-red-500", waiting: "bg-blue-50 text-blue-600",
};
const PICKING_LABEL: Record<string, string> = {
  draft: "Draft", confirmed: "Confirmed", assigned: "Ready",
  done: "Dispatched", cancel: "Cancelled", waiting: "Waiting",
};
const INVOICE_LABEL: Record<string, string> = {
  nothing: "—", to_invoice: "To Invoice", invoiced: "Invoiced", no: "—",
};

function Badge({ label, cls }: { label: string; cls: string }) {
  return (
    <span className={`inline-flex items-center px-2.5 py-1 rounded-full text-xs font-semibold ${cls}`}>
      {label}
    </span>
  );
}

function Section({ title, icon: Icon, children }: { title: string; icon: React.ElementType; children: React.ReactNode }) {
  return (
    <div className="mb-6">
      <div className="flex items-center gap-2 mb-3">
        <Icon className="w-4 h-4 text-slate-400" />
        <h3 className="text-xs font-semibold text-slate-400 uppercase tracking-wider">{title}</h3>
      </div>
      {children}
    </div>
  );
}

// ── Step config ────────────────────────────────────────────────────────────────
const STEPS: { key: StatusStep; label: string; icon: React.ElementType; color: string; bg: string; actionLabel: string }[] = [
  { key: "acknowledged", label: "Acknowledged",  icon: CheckCircle2, color: "text-blue-600",    bg: "bg-blue-50",    actionLabel: "Acknowledge Order" },
  { key: "packed",       label: "Packed",         icon: BoxSelect,    color: "text-amber-600",   bg: "bg-amber-50",   actionLabel: "Mark as Packed" },
  { key: "shipped",      label: "Shipped",        icon: Truck,        color: "text-emerald-600", bg: "bg-emerald-50", actionLabel: "Mark as Shipped" },
];

// ── Main Component ─────────────────────────────────────────────────────────────
export function OrderDetailDrawer({ orderId, orderName, onClose, canAct = false }: Props) {
  const [detail,          setDetail]          = useState<OrderDetail | null>(null);
  const [lines,           setLines]           = useState<OrderLine[]>([]);
  const [pickings,        setPickings]        = useState<Picking[]>([]);
  const [orderStatus,     setOrderStatus]     = useState<OrderStatus>(null);
  const [shippingAddress, setShippingAddress] = useState<ShippingAddress>(null);
  const [loading,     setLoading]     = useState(false);
  const [error,       setError]       = useState<string | null>(null);
  const [fromCache,   setFromCache]   = useState(false);
  const [stepLoading, setStepLoading] = useState<StatusStep | null>(null);
  const [srLoading,   setSrLoading]   = useState(false);
  const [srResult,    setSrResult]    = useState<{ id: number; shipmentId: number } | null>(null);
  const [srError,     setSrError]     = useState<string | null>(null);

  const fetchDetail = useCallback(async (id: number) => {
    setLoading(true);
    setError(null);
    setDetail(null);
    setLines([]);
    setPickings([]);
    setOrderStatus(null);
    setShippingAddress(null);
    setSrResult(null);
    setSrError(null);
    try {
      const res  = await fetch(`/api/dashboard/orders/${id}`);
      const data = await res.json();
      if (data.error) throw new Error(data.error);
      setDetail(data.order);
      setLines(Array.isArray(data.lines)       ? data.lines    : []);
      setPickings(Array.isArray(data.pickings) ? data.pickings : []);
      setFromCache(!!data.fromCache);
      setOrderStatus(data.orderStatus       ?? null);
      setShippingAddress(data.shippingAddress ?? null);
    } catch (e) {
      setError(e instanceof Error ? e.message : String(e));
    } finally {
      setLoading(false);
    }
  }, []);

  const markStep = async (step: StatusStep) => {
    if (!orderId || !detail) return;
    setStepLoading(step);
    try {
      const res  = await fetch(`/api/orders/${orderId}/status`, {
        method:  "POST",
        headers: { "Content-Type": "application/json" },
        body:    JSON.stringify({ step, orderName: detail.name, note: "" }),
      });
      const data = await res.json();
      if (data.ok) setOrderStatus(data.status);
    } finally {
      setStepLoading(null);
    }
  };

  const pushToShiprocket = async () => {
    if (!orderId) return;
    setSrLoading(true);
    setSrError(null);
    try {
      const res  = await fetch(`/api/orders/${orderId}/shiprocket`, { method: "POST", headers: { "Content-Type": "application/json" }, body: "{}" });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Shiprocket error");
      setSrResult({ id: data.shiprocket_order_id, shipmentId: data.shipment_id });
    } catch (e) {
      setSrError(e instanceof Error ? e.message : String(e));
    } finally {
      setSrLoading(false);
    }
  };

  useEffect(() => {
    if (orderId !== null) fetchDetail(orderId);
  }, [orderId, fetchDetail]);

  useEffect(() => {
    const handler = (e: KeyboardEvent) => { if (e.key === "Escape") onClose(); };
    document.addEventListener("keydown", handler);
    return () => document.removeEventListener("keydown", handler);
  }, [onClose]);

  const doneSteps = new Set((orderStatus?.timeline ?? []).map((e) => e.status));
  const isOpen    = orderId !== null;

  // Next step to take (first one not yet done)
  const nextStep  = STEPS.find((s) => !doneSteps.has(s.key));

  return (
    <>
      {/* Backdrop */}
      <div
        className={`fixed inset-0 bg-black/30 z-40 transition-opacity duration-300 ${isOpen ? "opacity-100" : "opacity-0 pointer-events-none"}`}
        onClick={onClose}
      />

      {/* Drawer */}
      <aside className={`fixed top-0 right-0 h-full w-full max-w-xl bg-white shadow-2xl z-50 flex flex-col transition-transform duration-300 ease-out ${isOpen ? "translate-x-0" : "translate-x-full"}`}>

        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-slate-100 flex items-center justify-center">
              <Hash className="w-4 h-4 text-slate-500" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900">{orderName || `Order #${orderId}`}</h2>
              <p className="text-xs text-slate-400">
                Order Detail
                {fromCache && <span className="ml-1 text-emerald-500">· cached</span>}
              </p>
            </div>
          </div>
          <button onClick={onClose} className="p-2 rounded-xl hover:bg-slate-100 transition-colors text-slate-400 hover:text-slate-600">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto px-6 py-5">

          {/* Loading skeleton */}
          {loading && (
            <div className="space-y-4">
              {[80, 120, 48, 100].map((h, i) => (
                <div key={i} className="bg-slate-100 animate-pulse rounded-xl" style={{ height: h }} />
              ))}
            </div>
          )}

          {/* Error */}
          {error && (
            <div className="bg-red-50 border border-red-100 rounded-xl p-4 text-sm text-red-600">
              Failed to load order. Please try again.
            </div>
          )}

          {detail && !loading && (
            <>
              {/* Status badges */}
              <div className="flex flex-wrap gap-2 mb-5 p-3 bg-slate-50 rounded-2xl">
                <Badge label={STATE_LABEL[detail.state] || detail.state} cls={STATE_STYLE[detail.state] || "bg-slate-100 text-slate-600"} />
                {detail.delivery_status && (
                  <Badge
                    label={detail.delivery_status === "full" ? "Dispatched" : detail.delivery_status === "partial" ? "Partial Dispatch" : "Pending Dispatch"}
                    cls={DELIVERY_STYLE[detail.delivery_status] || "bg-slate-100 text-slate-600"}
                  />
                )}
                <Badge label={INVOICE_LABEL[detail.invoice_status] || detail.invoice_status} cls="bg-slate-100 text-slate-600" />
                <span className="text-xs text-slate-400 self-center ml-auto">
                  {format(parseOdooDate(detail.date_order), "dd MMM yyyy, HH:mm")}
                </span>
              </div>

              {/* ── ORDER PROGRESS ─────────────────────────────────────── */}
              <Section title={`Order Progress${!canAct ? " (View only)" : ""}`} icon={Clock}>
                {/* Progress steps */}
                <div className="space-y-2 mb-4">
                  {STEPS.map((step, i) => {
                    const done     = doneSteps.has(step.key);
                    const isNext   = nextStep?.key === step.key;
                    const event    = (orderStatus?.timeline ?? []).find((e) => e.status === step.key);
                    const Icon     = step.icon;
                    const isLoading = stepLoading === step.key;

                    return (
                      <div key={step.key}>
                        {/* Step row */}
                        <div className={`flex items-center gap-3 p-3 rounded-xl border transition-all ${
                          done
                            ? `${step.bg} border-transparent`
                            : isNext
                            ? "bg-white border-slate-200 shadow-sm"
                            : "bg-slate-50 border-transparent opacity-50"
                        }`}>
                          <div className={`p-1.5 rounded-lg ${done ? step.bg : "bg-slate-100"}`}>
                            {done
                              ? <Icon className={`w-4 h-4 ${step.color}`} />
                              : <Circle className="w-4 h-4 text-slate-300" />
                            }
                          </div>
                          <div className="flex-1 min-w-0">
                            <div className={`text-sm font-semibold ${done ? "text-slate-800" : isNext ? "text-slate-700" : "text-slate-400"}`}>
                              {step.label}
                            </div>
                            {done && event && (
                              <div className="text-xs text-slate-500 mt-0.5">
                                {event.by.name} · {format(new Date(event.at), "dd MMM, HH:mm")}
                                {event.note && <span className="text-slate-400"> · "{event.note}"</span>}
                              </div>
                            )}
                          </div>
                          {done && <CheckCircle2 className={`w-4 h-4 ${step.color} shrink-0`} />}
                        </div>

                        {/* Action button — only for next step AND store_manager */}
                        {isNext && canAct && (
                          <button
                            onClick={() => markStep(step.key)}
                            disabled={!!isLoading}
                            className={`w-full mt-1.5 py-2.5 rounded-xl text-sm font-semibold flex items-center justify-center gap-2 transition-colors ${step.bg} ${step.color} hover:opacity-80 disabled:opacity-50`}
                          >
                            <Icon className="w-4 h-4" />
                            {isLoading ? "Saving…" : step.actionLabel}
                          </button>
                        )}
                      </div>
                    );
                  })}
                </div>

                {/* All done state */}
                {doneSteps.has("shipped") && (
                  <div className="flex items-center gap-2 p-3 bg-emerald-50 rounded-xl text-sm text-emerald-700 font-medium">
                    <CheckCircle2 className="w-4 h-4" />
                    All steps complete — order shipped ✓
                  </div>
                )}
              </Section>

              {/* ── SHIPROCKET ──────────────────────────────────────────── */}
              {["sale", "done"].includes(detail.state) && (
                <Section title="Courier" icon={Truck}>
                  {srResult ? (
                    <div className="flex items-center gap-3 p-3 bg-emerald-50 border border-emerald-100 rounded-xl text-sm">
                      <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
                      <div>
                        <div className="font-semibold text-emerald-700">Created in Shiprocket</div>
                        <div className="text-xs text-emerald-600 mt-0.5">
                          Order #{srResult.id} · Shipment #{srResult.shipmentId}
                        </div>
                      </div>
                    </div>
                  ) : (
                    <>
                      <button
                        onClick={pushToShiprocket}
                        disabled={srLoading}
                        className="w-full flex items-center justify-center gap-2 py-2.5 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white rounded-xl text-sm font-semibold transition-colors"
                      >
                        <Truck className="w-4 h-4" />
                        {srLoading ? "Creating in Shiprocket…" : "Push to Shiprocket"}
                      </button>
                      {srError && (
                        <p className="mt-2 text-xs text-red-500 bg-red-50 rounded-lg px-3 py-2">{srError}</p>
                      )}
                      <p className="mt-1.5 text-xs text-slate-400 text-center">Creates order only · does not auto-assign courier</p>
                    </>
                  )}
                </Section>
              )}

              {/* ── CUSTOMER ────────────────────────────────────────────── */}
              <Section title="Customer & Delivery Address" icon={User}>
                <div className="bg-slate-50 rounded-xl p-4 space-y-2 text-sm">
                  <div className="flex items-start gap-2">
                    <User className="w-4 h-4 text-slate-400 mt-0.5 shrink-0" />
                    <span className="font-medium text-slate-800">{detail.partner_id[1]}</span>
                  </div>
                  {/* Shipping address */}
                  {shippingAddress ? (
                    <div className="flex items-start gap-2 text-slate-600">
                      <MapPin className="w-4 h-4 text-slate-400 mt-0.5 shrink-0" />
                      <div className="leading-relaxed">
                        {shippingAddress.street && <div>{shippingAddress.street}</div>}
                        {shippingAddress.street2 && <div>{shippingAddress.street2}</div>}
                        <div className="font-medium text-slate-800">
                          {[
                            shippingAddress.city,
                            Array.isArray(shippingAddress.state_id) ? shippingAddress.state_id[1] : null,
                            shippingAddress.zip,
                          ].filter(Boolean).join(", ")}
                        </div>
                        {Array.isArray(shippingAddress.country_id) && (
                          <div className="text-slate-400 text-xs">{shippingAddress.country_id[1]}</div>
                        )}
                      </div>
                    </div>
                  ) : Array.isArray(detail.partner_shipping_id) ? (
                    <div className="flex items-start gap-2 text-slate-500">
                      <MapPin className="w-4 h-4 text-slate-400 mt-0.5 shrink-0" />
                      <span>{(detail.partner_shipping_id as [number, string])[1]}</span>
                    </div>
                  ) : null}
                  {Array.isArray(detail.carrier_id) && (
                    <div className="flex items-start gap-2 text-slate-500">
                      <Truck className="w-4 h-4 text-slate-400 mt-0.5 shrink-0" />
                      <span>via {(detail.carrier_id as [number, string])[1]}</span>
                    </div>
                  )}
                </div>
              </Section>

              {/* ── PRODUCTS ─────────────────────────────────────────────── */}
              <Section title={`Products (${lines.length})`} icon={Package}>
                <div className="rounded-xl border border-slate-100 overflow-hidden">
                  {lines.length === 0 ? (
                    <div className="py-8 text-center text-sm text-slate-400">No items</div>
                  ) : (
                    <table className="w-full text-sm">
                      <thead>
                        <tr className="bg-slate-50 text-xs text-slate-400 uppercase tracking-wider">
                          <th className="px-4 py-3 text-left font-medium">Product</th>
                          <th className="px-4 py-3 text-right font-medium">Qty</th>
                          <th className="px-4 py-3 text-right font-medium">Unit</th>
                          <th className="px-4 py-3 text-right font-medium">Total</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-50">
                        {lines.map((line) => (
                          <tr key={line.id} className="hover:bg-slate-50">
                            <td className="px-4 py-3">
                              <div className="font-medium text-slate-800 leading-tight">
                                {line.product_id ? line.product_id[1] : line.name}
                              </div>
                              {line.discount > 0 && (
                                <span className="text-xs text-emerald-600">{line.discount}% off</span>
                              )}
                              {line.qty_delivered > 0 && (
                                <span className="text-xs text-blue-500 ml-2">Delivered: {line.qty_delivered}</span>
                              )}
                            </td>
                            <td className="px-4 py-3 text-right text-slate-600 whitespace-nowrap">
                              {line.product_uom_qty} {line.product_uom_id ? line.product_uom_id[1] : ""}
                            </td>
                            <td className="px-4 py-3 text-right text-slate-600 whitespace-nowrap">
                              {formatINR(line.price_unit)}
                            </td>
                            <td className="px-4 py-3 text-right font-semibold text-slate-900 whitespace-nowrap">
                              {formatINR(line.price_subtotal)}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  )}
                </div>
              </Section>

              {/* ── SUMMARY ──────────────────────────────────────────────── */}
              <Section title="Payment Summary" icon={CreditCard}>
                <div className="bg-slate-50 rounded-xl p-4 space-y-2 text-sm">
                  <div className="flex justify-between text-slate-600">
                    <span>Subtotal</span>
                    <span>{formatINR(detail.amount_untaxed ?? 0)}</span>
                  </div>
                  <div className="flex justify-between text-slate-600">
                    <span>Tax</span>
                    <span>{formatINR(detail.amount_tax ?? 0)}</span>
                  </div>
                  {detail.amount_delivery > 0 && (
                    <div className="flex justify-between text-slate-600">
                      <span>Delivery</span>
                      <span>{formatINR(detail.amount_delivery)}</span>
                    </div>
                  )}
                  <div className="flex justify-between font-bold text-slate-900 pt-2 border-t border-slate-200">
                    <span>Total</span>
                    <span className="text-lg">{formatINR(detail.amount_total)}</span>
                  </div>
                </div>
              </Section>

              {/* ── DELIVERIES ───────────────────────────────────────────── */}
              {pickings.length > 0 && (
                <Section title={`Deliveries (${pickings.length})`} icon={Truck}>
                  <div className="space-y-2">
                    {pickings.map((p) => (
                      <div key={p.id} className="flex items-center justify-between bg-slate-50 rounded-xl px-4 py-3">
                        <div>
                          <div className="font-medium text-sm text-slate-800">{p.name}</div>
                          <div className="text-xs text-slate-400 mt-0.5">
                            {p.state === "done" && p.date_done
                              ? `Dispatched ${format(parseOdooDate(p.date_done), "dd MMM yyyy")}`
                              : p.scheduled_date
                              ? `Scheduled ${format(parseOdooDate(p.scheduled_date), "dd MMM yyyy")}`
                              : "No date"}
                          </div>
                        </div>
                        <Badge label={PICKING_LABEL[p.state] || p.state} cls={PICKING_STYLE[p.state] || "bg-slate-100 text-slate-600"} />
                      </div>
                    ))}
                  </div>
                </Section>
              )}

              {/* ── NOTES ────────────────────────────────────────────────── */}
              {typeof detail.note === "string" && detail.note.trim() && (
                <Section title="Order Notes" icon={ChevronRight}>
                  <div className="bg-amber-50 border border-amber-100 rounded-xl p-4 text-sm text-amber-800 leading-relaxed">
                    {detail.note.replace(/<[^>]*>/g, " ").trim()}
                  </div>
                </Section>
              )}
            </>
          )}
        </div>
      </aside>
    </>
  );
}
