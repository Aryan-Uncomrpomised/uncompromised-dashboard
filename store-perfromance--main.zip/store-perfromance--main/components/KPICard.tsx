"use client";

import { cn } from "@/lib/utils";
import { LucideIcon } from "lucide-react";

interface KPICardProps {
  title: string;
  value: string;
  subtitle?: string;
  icon: LucideIcon;
  iconColor?: string;
  trend?: { value: number; label: string };
  loading?: boolean;
}

export function KPICard({ title, value, subtitle, icon: Icon, iconColor = "text-brand-600", trend, loading }: KPICardProps) {
  return (
    <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-5 flex flex-col gap-3 hover:shadow-md transition-shadow">
      <div className="flex items-center justify-between">
        <span className="text-sm font-medium text-slate-500">{title}</span>
        <div className={cn("p-2 rounded-xl bg-slate-50", iconColor.replace("text-", "text-"))}>
          <Icon className={cn("w-4 h-4", iconColor)} strokeWidth={2} />
        </div>
      </div>
      {loading ? (
        <div className="h-8 w-28 bg-slate-100 animate-pulse rounded-lg" />
      ) : (
        <div className="text-2xl font-bold text-slate-900 tracking-tight">{value}</div>
      )}
      {subtitle && (
        <p className="text-xs text-slate-400">{subtitle}</p>
      )}
      {trend && !loading && (
        <div className={cn("text-xs font-medium flex items-center gap-1", trend.value >= 0 ? "text-emerald-600" : "text-red-500")}>
          <span>{trend.value >= 0 ? "↑" : "↓"} {Math.abs(trend.value)}%</span>
          <span className="text-slate-400 font-normal">{trend.label}</span>
        </div>
      )}
    </div>
  );
}
