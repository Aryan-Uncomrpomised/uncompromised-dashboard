import { NextRequest, NextResponse } from "next/server";
import { verifySessionToken, SESSION_COOKIE } from "@/lib/session";

const PUBLIC_PATHS = ["/login", "/api/auth", "/api/cron", "/offline.html"];

export async function middleware(req: NextRequest) {
  const { pathname } = req.nextUrl;

  // Allow public paths through
  if (PUBLIC_PATHS.some((p) => pathname.startsWith(p))) {
    return NextResponse.next();
  }

  const token = req.cookies.get(SESSION_COOKIE)?.value;

  if (!token) {
    const loginUrl = req.nextUrl.clone();
    loginUrl.pathname = "/login";
    return NextResponse.redirect(loginUrl);
  }

  const payload = await verifySessionToken(token);
  if (!payload) {
    const loginUrl = req.nextUrl.clone();
    loginUrl.pathname = "/login";
    const res = NextResponse.redirect(loginUrl);
    res.cookies.set(SESSION_COOKIE, "", { maxAge: 0, path: "/" }); // clear invalid cookie
    return res;
  }

  // Admin-only routes
  if (
    pathname.startsWith("/admin") ||
    pathname.startsWith("/api/users") ||
    pathname.startsWith("/top-products") ||
    pathname.startsWith("/api/top-products")
  ) {
    if (payload.role !== "store_admin") {
      const homeUrl = req.nextUrl.clone();
      homeUrl.pathname = "/";
      return NextResponse.redirect(homeUrl);
    }
  }

  // Pass user info to the request via headers (readable by server components / API routes)
  const requestHeaders = new Headers(req.headers);
  requestHeaders.set("x-user-id",    payload.sub);
  requestHeaders.set("x-user-email", payload.email);
  requestHeaders.set("x-user-name",  payload.name);
  requestHeaders.set("x-user-role",  payload.role);

  return NextResponse.next({ request: { headers: requestHeaders } });
}

export const config = {
  matcher: [
    "/((?!_next/static|_next/image|favicon.ico|manifest.json|sw.js|offline.html|icon.*|apple-touch-icon.*|logo.*).*)",
  ],
};
