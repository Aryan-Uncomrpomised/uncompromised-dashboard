/**
 * Run once to seed the first admin user:
 * node scripts/seed-admin.mjs
 */

import { MongoClient } from "mongodb";
import bcrypt from "bcryptjs";
import { config } from "dotenv";

config({ path: ".env" });
config({ path: ".env.local" });

const MONGO_URL = process.env.MONGO_URL;
const DB_NAME   = "uc_dashboard";

if (!MONGO_URL) { console.error("MONGO_URL not set"); process.exit(1); }

const client = new MongoClient(MONGO_URL, {
  tls: true,
  tlsAllowInvalidCertificates: true, // local Node 24 SSL workaround
});

async function seed() {
  await client.connect();
  console.log("✓ Connected to MongoDB");

  const db  = client.db(DB_NAME);
  const col = db.collection("users");

  // Indexes
  await col.createIndex({ email:    1 }, { unique: true }).catch(() => {});
  await col.createIndex({ username: 1 }, { unique: true, sparse: true }).catch(() => {});

  const existing = await col.findOne({ $or: [{ email: "orders@uncompromised.in" }, { username: "admin" }] });
  if (existing) {
    console.log("⚠ Admin user already exists:", existing.email);
    await client.close();
    return;
  }

  const passwordHash = await bcrypt.hash("farmshop2025", 12);
  await col.insertOne({
    username:     "admin",
    email:        "orders@uncompromised.in",
    name:         "Admin",
    role:         "store_admin",
    passwordHash,
    createdAt:    new Date(),
  });

  console.log("✓ Admin user created:");
  console.log("  Username : admin");
  console.log("  Email    : orders@uncompromised.in");
  console.log("  Password : farmshop2025");
  console.log("  Role     : store_admin");

  await client.close();
}

seed().catch((e) => { console.error("✗ Error:", e.message); process.exit(1); });
