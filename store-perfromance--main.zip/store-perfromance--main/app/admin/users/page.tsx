"use client";

import { useEffect, useState, FormEvent } from "react";
import { useRouter } from "next/navigation";
import { UserPlus, Trash2, ArrowLeft, ShieldCheck, User } from "lucide-react";
import type { UserRole } from "@/lib/session";

type SafeUser = {
  _id: string;
  email: string;
  name: string;
  role: UserRole;
  createdAt: string;
  lastLoginAt?: string;
};

export default function UsersPage() {
  const router = useRouter();
  const [users,   setUsers]   = useState<SafeUser[]>([]);
  const [loading, setLoading] = useState(true);
  const [error,   setError]   = useState("");

  // New user form
  const [form,        setForm]        = useState({ email: "", name: "", password: "", role: "store_manager" as UserRole });
  const [formLoading, setFormLoading] = useState(false);
  const [formError,   setFormError]   = useState("");
  const [formSuccess, setFormSuccess] = useState("");

  async function load() {
    setLoading(true);
    const res  = await fetch("/api/users");
    if (!res.ok) { setError("Forbidden or error loading users"); setLoading(false); return; }
    const data = await res.json();
    setUsers(data.users);
    setLoading(false);
  }

  useEffect(() => { load(); }, []);

  async function handleCreate(e: FormEvent) {
    e.preventDefault();
    setFormError(""); setFormSuccess("");
    setFormLoading(true);
    try {
      const res = await fetch("/api/users", {
        method:  "POST",
        headers: { "Content-Type": "application/json" },
        body:    JSON.stringify(form),
      });
      const data = await res.json();
      if (!res.ok) { setFormError(data.error || "Failed to create user"); return; }
      setFormSuccess(`${data.user.name} created successfully`);
      setForm({ email: "", name: "", password: "", role: "store_manager" });
      load();
    } finally {
      setFormLoading(false);
    }
  }

  async function handleDelete(id: string, name: string) {
    if (!confirm(`Delete ${name}? This cannot be undone.`)) return;
    await fetch(`/api/users?id=${id}`, { method: "DELETE" });
    load();
  }

  return (
    <div className="min-h-screen bg-slate-50">
      <header className="bg-white border-b border-slate-200 sticky top-0 z-40">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 py-4 flex items-center gap-4">
          <button onClick={() => router.push("/")} className="p-2 rounded-xl hover:bg-slate-100 transition-colors text-slate-500">
            <ArrowLeft className="w-4 h-4" />
          </button>
          <div className="flex items-center gap-2.5">
            <img src="/logo.svg" alt="" className="w-8 h-8 rounded-xl" />
            <div>
              <h1 className="text-sm font-bold text-slate-900">User Management</h1>
              <p className="text-xs text-slate-400">Admin only</p>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-3xl mx-auto px-4 sm:px-6 py-8 space-y-8">

        {/* Add user form */}
        <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-6">
          <div className="flex items-center gap-2 mb-5">
            <UserPlus className="w-5 h-5 text-slate-500" />
            <h2 className="text-base font-semibold text-slate-800">Add User</h2>
          </div>

          <form onSubmit={handleCreate} className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-500 mb-1">Full Name</label>
              <input
                type="text" required value={form.name}
                onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))}
                className="w-full border border-slate-200 rounded-xl px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500"
                placeholder="Ravi Kumar"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-500 mb-1">Email</label>
              <input
                type="email" required value={form.email}
                onChange={(e) => setForm((f) => ({ ...f, email: e.target.value }))}
                className="w-full border border-slate-200 rounded-xl px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500"
                placeholder="ravi@uncompromised.in"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-500 mb-1">Password</label>
              <input
                type="password" required value={form.password} minLength={8}
                onChange={(e) => setForm((f) => ({ ...f, password: e.target.value }))}
                className="w-full border border-slate-200 rounded-xl px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500"
                placeholder="Min 8 characters"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-500 mb-1">Role</label>
              <select
                value={form.role}
                onChange={(e) => setForm((f) => ({ ...f, role: e.target.value as UserRole }))}
                className="w-full border border-slate-200 rounded-xl px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-brand-500 bg-white"
              >
                <option value="store_manager">Store Manager</option>
                <option value="store_admin">Store Admin</option>
              </select>
            </div>

            {formError   && <p className="sm:col-span-2 text-xs text-red-600 bg-red-50 rounded-xl px-3 py-2">{formError}</p>}
            {formSuccess && <p className="sm:col-span-2 text-xs text-emerald-600 bg-emerald-50 rounded-xl px-3 py-2">{formSuccess}</p>}

            <div className="sm:col-span-2">
              <button
                type="submit" disabled={formLoading}
                className="px-5 py-2 bg-brand-600 text-white rounded-xl text-sm font-medium hover:bg-brand-700 disabled:opacity-50 transition-colors"
              >
                {formLoading ? "Creating…" : "Create User"}
              </button>
            </div>
          </form>
        </div>

        {/* Users list */}
        <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-6">
          <h2 className="text-base font-semibold text-slate-800 mb-5">Team Members ({users.length})</h2>

          {loading ? (
            <div className="space-y-3">
              {[1,2,3].map((i) => <div key={i} className="h-14 bg-slate-100 animate-pulse rounded-xl" />)}
            </div>
          ) : error ? (
            <p className="text-sm text-red-500">{error}</p>
          ) : (
            <div className="space-y-2">
              {users.map((u) => (
                <div key={u._id} className="flex items-center justify-between p-4 bg-slate-50 rounded-xl">
                  <div className="flex items-center gap-3">
                    <div className={`p-2 rounded-lg ${u.role === "store_admin" ? "bg-amber-100" : "bg-blue-50"}`}>
                      {u.role === "store_admin"
                        ? <ShieldCheck className="w-4 h-4 text-amber-600" />
                        : <User className="w-4 h-4 text-blue-600" />
                      }
                    </div>
                    <div>
                      <div className="font-medium text-sm text-slate-800">{u.name}</div>
                      <div className="text-xs text-slate-400">{u.email} · {u.role === "store_admin" ? "Admin" : "Manager"}</div>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className="text-xs text-slate-400 hidden sm:block">
                      {u.lastLoginAt ? `Last login: ${new Date(u.lastLoginAt).toLocaleDateString()}` : "Never logged in"}
                    </span>
                    <button
                      onClick={() => handleDelete(u._id, u.name)}
                      className="p-2 text-slate-400 hover:text-red-500 hover:bg-red-50 rounded-lg transition-colors"
                      title="Delete user"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </main>
    </div>
  );
}
