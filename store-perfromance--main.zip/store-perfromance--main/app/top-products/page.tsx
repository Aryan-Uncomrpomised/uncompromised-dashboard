"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { format, subDays } from "date-fns";
import { ArrowLeft, RefreshCw, TrendingUp, IndianRupee, Weight, ChevronUp, ChevronDown } from "lucide-react";
import type { TopProductsResult, TopProduct } from "@/app/api/top-products/route";

type Source  = "all" | "website" | "pos";
type SortBy  = "revenue" | "weight";

const CATEGORY_COLORS: Record<string, string> = {
  Flour:                 "bg-amber-100 text-amber-800",
  Lentils:               "bg-orange-100 text-orange-800",
  Grains:                "bg-yellow-100 text-yellow-800",
  Spices:                "bg-red-100 text-red-800",
  Oil:                   "bg-lime-100 text-lime-800",
  Vegetables:            "bg-green-100 text-green-800",
  Fruits:                "bg-pink-100 text-pink-800",
  Seeds:                 "bg-teal-100 text-teal-800",
  Pickle:                "bg-purple-100 text-purple-800",
  "Chutney/Jam":         "bg-rose-100 text-rose-800",
  "Exotic Vegetables":   "bg-emerald-100 text-emerald-800",
  "Minimally Processed": "bg-cyan-100 text-cyan-800",
  "Farm Sourced":        "bg-indigo-100 text-indigo-800",
  Other:                 "bg-slate-100 text-slate-600",
};
function catColor(name: string) { return CATEGORY_COLORS[name] ?? CATEGORY_COLORS.Other; }

function formatINR(n: number) {
  return new Intl.NumberFormat("en-IN", { style: "currency", currency: "INR", maximumFractionDigits: 0 }).format(n);
}
function formatWeight(grams: number) {
  if (!grams) return "—";
  if (grams >= 1000) return `${parseFloat((grams / 1000).toFixed(2))} kg`;
  return `${grams} g`;
}

function defaultFrom() { return format(subDays(new Date(), 29), "yyyy-MM-dd"); }
function defaultTo()   { return format(new Date(), "yyyy-MM-dd"); }

// Rank medal for top 3
function Rank({ n }: { n: number }) {
  if (n === 1) return <span className="inline-flex items-center justify-center w-7 h-7 rounded-full bg-amber-400 text-white text-xs font-bold shadow">1</span>;
  if (n === 2) return <span className="inline-flex items-center justify-center w-7 h-7 rounded-full bg-slate-400 text-white text-xs font-bold shadow">2</span>;
  if (n === 3) return <span className="inline-flex items-center justify-center w-7 h-7 rounded-full bg-amber-700 text-white text-xs font-bold shadow">3</span>;
  return <span className="inline-flex items-center justify-center w-7 h-7 text-slate-400 text-xs font-semibold">{n}</span>;
}

function SortHeader({ label, field, sortBy, onSort }: { label: string; field: SortBy; sortBy: SortBy; onSort: (f: SortBy) => void }) {
  const active = sortBy === field;
  return (
    <button
      onClick={() => onSort(field)}
      className={`flex items-center gap-1 text-xs font-semibold uppercase tracking-wide transition-colors ${active ? "text-brand-600" : "text-slate-400 hover:text-slate-600"}`}
    >
      {label}
      {active ? <ChevronDown className="w-3 h-3" /> : <ChevronUp className="w-3 h-3 opacity-30" />}
    </button>
  );
}

export default function TopProductsPage() {
  const router = useRouter();

  const [from,    setFrom]    = useState(defaultFrom());
  const [to,      setTo]      = useState(defaultTo());
  const [source,  setSource]  = useState<Source>("all");
  const [sortBy,  setSortBy]  = useState<SortBy>("revenue");
  const [result,  setResult]  = useState<TopProductsResult | null>(null);
  const [loading, setLoading] = useState(false);
  const [error,   setError]   = useState("");

  async function generate() {
    setLoading(true);
    setError("");
    setResult(null);
    try {
      const params = new URLSearchParams({ from, to, source });
      const res    = await fetch(`/api/top-products?${params}`);
      const data   = await res.json();
      if (!res.ok) throw new Error(data.error || "Failed");
      setResult(data);
    } catch (e) {
      setError(e instanceof Error ? e.message : String(e));
    } finally {
      setLoading(false);
    }
  }

  const sorted: TopProduct[] = result
    ? [...result.products].sort((a, b) =>
        sortBy === "weight" ? b.totalGrams - a.totalGrams : b.revenue - a.revenue
      )
    : [];

  const SOURCES: { key: Source; label: string }[] = [
    { key: "all",     label: "All" },
    { key: "website", label: "Website" },
    { key: "pos",     label: "POS" },
  ];

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Header */}
      <header className="bg-white border-b border-slate-200 sticky top-0 z-40">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 py-4 flex items-center gap-4">
          <button onClick={() => router.push("/")} className="p-2 rounded-xl hover:bg-slate-100 text-slate-500">
            <ArrowLeft className="w-4 h-4" />
          </button>
          <div className="flex items-center gap-2.5">
            <img src="/logo.svg" alt="" className="w-8 h-8 rounded-xl" />
            <div>
              <h1 className="text-sm font-bold text-slate-900">Top Selling Products</h1>
              <p className="text-xs text-slate-400">Revenue &amp; weight by product template</p>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-5xl mx-auto px-4 sm:px-6 py-6 space-y-5">

        {/* Filters */}
        <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-5 space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-500 mb-1.5">From</label>
              <input
                type="date"
                value={from}
                onChange={(e) => setFrom(e.target.value)}
                className="w-full border border-slate-200 rounded-xl px-3 py-2.5 text-sm text-slate-700 focus:outline-none focus:ring-2 focus:ring-brand-500"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-500 mb-1.5">To</label>
              <input
                type="date"
                value={to}
                onChange={(e) => setTo(e.target.value)}
                className="w-full border border-slate-200 rounded-xl px-3 py-2.5 text-sm text-slate-700 focus:outline-none focus:ring-2 focus:ring-brand-500"
              />
            </div>
          </div>

          {/* Source filter */}
          <div className="flex items-center gap-2">
            <span className="text-xs font-medium text-slate-500 mr-1">Source:</span>
            <div className="flex rounded-xl border border-slate-200 overflow-hidden">
              {SOURCES.map(({ key, label }) => (
                <button
                  key={key}
                  onClick={() => setSource(key)}
                  className={`px-4 py-1.5 text-xs font-semibold transition-colors ${
                    source === key
                      ? "bg-slate-900 text-white"
                      : "bg-white text-slate-500 hover:bg-slate-50"
                  }`}
                >
                  {label}
                </button>
              ))}
            </div>
          </div>

          <button
            onClick={generate}
            disabled={loading || !from || !to}
            className="w-full py-2.5 bg-brand-600 text-white rounded-xl text-sm font-semibold hover:bg-brand-700 disabled:opacity-50 flex items-center justify-center gap-2 transition-colors"
          >
            <RefreshCw className={`w-4 h-4 ${loading ? "animate-spin" : ""}`} />
            {loading ? "Fetching from Odoo…" : "Generate Report"}
          </button>
        </div>

        {error && (
          <div className="bg-red-50 border border-red-100 rounded-2xl p-4 text-sm text-red-600">{error}</div>
        )}

        {/* Results */}
        {result && (
          <div className="space-y-4">
            {/* Summary row */}
            <div className="grid grid-cols-3 gap-3">
              <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-4 flex flex-col gap-1">
                <span className="text-xs text-slate-400">Products</span>
                <span className="text-2xl font-bold text-slate-900">{result.products.length}</span>
              </div>
              <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-4 flex flex-col gap-1">
                <span className="text-xs text-slate-400 flex items-center gap-1"><IndianRupee className="w-3 h-3" />Total Revenue</span>
                <span className="text-2xl font-bold text-slate-900">{formatINR(result.totalRevenue)}</span>
              </div>
              <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-4 flex flex-col gap-1">
                <span className="text-xs text-slate-400 flex items-center gap-1"><Weight className="w-3 h-3" />Total Weight</span>
                <span className="text-2xl font-bold text-slate-900">{formatWeight(result.totalWeight)}</span>
              </div>
            </div>

            {/* Table */}
            {sorted.length === 0 ? (
              <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-12 text-center text-slate-400 text-sm">
                No confirmed orders found in this date range.
              </div>
            ) : (
              <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
                {/* Table header */}
                <div className="grid grid-cols-[40px_1fr_120px_100px_130px_130px] gap-x-4 px-5 py-3 border-b border-slate-100 bg-slate-50">
                  <div />
                  <span className="text-xs font-semibold text-slate-400 uppercase tracking-wide">Product</span>
                  <span className="text-xs font-semibold text-slate-400 uppercase tracking-wide">Units</span>
                  <div className="flex justify-end">
                    <SortHeader label="Weight" field="weight" sortBy={sortBy} onSort={setSortBy} />
                  </div>
                  <div className="flex justify-end">
                    <SortHeader label="Revenue" field="revenue" sortBy={sortBy} onSort={setSortBy} />
                  </div>
                  <span className="text-xs font-semibold text-slate-400 uppercase tracking-wide text-right">% of Total</span>
                </div>

                {/* Rows */}
                <div className="divide-y divide-slate-50">
                  {sorted.map((p, i) => {
                    const pct = result.totalRevenue > 0
                      ? ((p.revenue / result.totalRevenue) * 100).toFixed(1)
                      : "0.0";
                    return (
                      <div
                        key={p.templateId}
                        className={`grid grid-cols-[40px_1fr_120px_100px_130px_130px] gap-x-4 px-5 py-3.5 items-center ${i < 3 ? "bg-amber-50/30" : ""} hover:bg-slate-50 transition-colors`}
                      >
                        <Rank n={i + 1} />

                        <div className="min-w-0">
                          <p className="text-sm font-semibold text-slate-800 truncate">{p.name}</p>
                          <span className={`inline-block mt-0.5 text-[10px] font-medium px-1.5 py-0.5 rounded-md ${catColor(p.category)}`}>
                            {p.category}
                          </span>
                        </div>

                        <span className="text-sm text-slate-600 tabular-nums">{p.units.toLocaleString("en-IN")}</span>

                        <span className="text-sm text-slate-600 tabular-nums text-right">{p.weightLabel}</span>

                        <span className={`text-sm font-semibold tabular-nums text-right ${sortBy === "revenue" ? "text-brand-700" : "text-slate-700"}`}>
                          {formatINR(p.revenue)}
                        </span>

                        <div className="flex flex-col items-end gap-1">
                          <span className="text-xs font-semibold text-slate-500 tabular-nums">{pct}%</span>
                          <div className="w-full h-1.5 bg-slate-100 rounded-full overflow-hidden">
                            <div
                              className="h-full bg-brand-500 rounded-full"
                              style={{ width: `${Math.min(100, parseFloat(pct))}%` }}
                            />
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}
          </div>
        )}
      </main>
    </div>
  );
}
