import { NextRequest, NextResponse } from "next/server";
import { verifySessionToken, SESSION_COOKIE } from "@/lib/session";
import { odoo } from "@/lib/odoo";

function parsePackSize(str: string): number | null {
  const m = str.trim().match(/^([\d.]+)\s*(kg|gms?|g|ml|l)s?$/i);
  if (!m) return null;
  const val  = parseFloat(m[1]);
  const unit = m[2].toLowerCase();
  if (unit === "kg")                   return val * 1000;
  if (unit === "g" || unit.startsWith("gm")) return val;
  if (unit === "l")                    return val * 1000;
  if (unit === "ml")                   return val;
  return null;
}

function formatWeight(grams: number): string {
  if (grams >= 1000) return `${parseFloat((grams / 1000).toFixed(2))} kg`;
  return `${grams} g`;
}

function stripSku(name: string): string {
  return name.replace(/^\[[^\]]+\]\s*/, "").trim();
}

const EXCLUDE_KEYWORDS = ["shipping", "delivery", "discount", "coupon", "fee", "charge"];
function isPhysical(name: string): boolean {
  const lower = name.toLowerCase();
  return !EXCLUDE_KEYWORDS.some((k) => lower.includes(k));
}

export interface TopProduct {
  templateId:  number;
  name:        string;
  category:    string;
  units:       number;
  totalGrams:  number;
  weightLabel: string;
  revenue:     number;
}

export interface TopProductsResult {
  products:     TopProduct[];
  from:         string;
  to:           string;
  source:       string;
  totalRevenue: number;
  totalWeight:  number;
}

export async function GET(req: NextRequest) {
  const token   = req.cookies.get(SESSION_COOKIE)?.value;
  const session = token ? await verifySessionToken(token) : null;
  if (!session)                        return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  if (session.role !== "store_admin")  return NextResponse.json({ error: "Forbidden" },    { status: 403 });

  const { searchParams } = new URL(req.url);
  const from   = searchParams.get("from")   || "";
  const to     = searchParams.get("to")     || "";
  const source = searchParams.get("source") || "all";

  if (!from || !to) return NextResponse.json({ error: "from and to are required" }, { status: 400 });

  // Odoo date range (full days)
  const odooFrom = `${from} 00:00:00`;
  const odooTo   = `${to} 23:59:59`;

  try {
    // ── 1. Fetch order lines ──────────────────────────────────────────────────
    const [websiteRaw, posRaw] = await Promise.all([
      source !== "pos"     ? odoo.getOrderLinesWithRevenue(odooFrom, odooTo)   : Promise.resolve([]),
      source !== "website" ? odoo.getPOSOrderLinesInPeriod(odooFrom, odooTo)   : Promise.resolve([]),
    ]);

    type RawLine = { productId: number; name: string; qty: number; revenue: number };
    const rawLines: RawLine[] = [];

    for (const l of websiteRaw) {
      if (!l.product_id) continue;
      rawLines.push({ productId: l.product_id[0], name: l.product_id[1], qty: l.product_uom_qty, revenue: l.price_subtotal });
    }
    for (const l of posRaw) {
      if (!l.product_id) continue;
      rawLines.push({ productId: (l.product_id as [number, string])[0], name: (l.product_id as [number, string])[1], qty: l.qty, revenue: l.price_subtotal });
    }

    const physicalLines = rawLines.filter((l) => isPhysical(stripSku(l.name)));
    if (!physicalLines.length) {
      return NextResponse.json({ products: [], from, to, source, totalRevenue: 0, totalWeight: 0 });
    }

    // ── 2. Variant → template mapping + pack sizes + categories ──────────────
    const productIds = [...new Set(physicalLines.map((l) => l.productId))];
    const variants   = await odoo.getProductVariants(productIds);

    const allAttrValueIds = [...new Set(variants.flatMap((v) => v.product_template_attribute_value_ids))];
    const packSizeValues  = await odoo.getPackSizeValues(allAttrValueIds);
    const packSizeMap     = new Map(packSizeValues.map((p) => [p.id, p.name]));

    const templateIds = [...new Set(variants.map((v) => v.product_tmpl_id[0]))];
    const [templates, publicCategories] = await Promise.all([
      odoo.getProductTemplatesWithCategories(templateIds),
      odoo.getPublicCategories(),
    ]);

    const categoryMap = new Map(publicCategories.map((c) => [c.id, c.name]));
    const templateMap = new Map(templates.map((t) => [t.id, t]));
    const variantMap  = new Map(variants.map((v) => [v.id, v]));

    // ── 3. Aggregate by product template ────────────────────────────────────
    const acc = new Map<number, { name: string; category: string; units: number; totalGrams: number; revenue: number }>();

    for (const line of physicalLines) {
      const variant = variantMap.get(line.productId);
      if (!variant) continue;

      const tmplId   = variant.product_tmpl_id[0];
      const tmpl     = templateMap.get(tmplId);
      const tmplName = stripSku(variant.product_tmpl_id[1]);

      const catId   = tmpl?.public_categ_ids?.[0];
      const catName = catId ? (categoryMap.get(catId) ?? "Other") : "Other";

      const packAttrId   = variant.product_template_attribute_value_ids.find((id) => packSizeMap.has(id));
      const packSizeStr  = packAttrId ? (packSizeMap.get(packAttrId) ?? "") : "";
      const gramsPerUnit = parsePackSize(packSizeStr) ?? 0;

      const existing = acc.get(tmplId) ?? { name: tmplName, category: catName, units: 0, totalGrams: 0, revenue: 0 };
      existing.units      += line.qty;
      existing.totalGrams += gramsPerUnit * line.qty;
      existing.revenue    += line.revenue;
      acc.set(tmplId, existing);
    }

    // ── 4. Build output ───────────────────────────────────────────────────────
    const products: TopProduct[] = [...acc.entries()].map(([tmplId, data]) => ({
      templateId:  tmplId,
      name:        data.name,
      category:    data.category,
      units:       Math.round(data.units * 100) / 100,
      totalGrams:  Math.round(data.totalGrams),
      weightLabel: data.totalGrams > 0 ? formatWeight(data.totalGrams) : "—",
      revenue:     Math.round(data.revenue * 100) / 100,
    }));

    const totalRevenue = products.reduce((s, p) => s + p.revenue, 0);
    const totalWeight  = products.reduce((s, p) => s + p.totalGrams, 0);

    return NextResponse.json({ products, from, to, source, totalRevenue, totalWeight } satisfies TopProductsResult);

  } catch (err) {
    console.error("[top-products]", err);
    return NextResponse.json({ error: String(err) }, { status: 500 });
  }
}
