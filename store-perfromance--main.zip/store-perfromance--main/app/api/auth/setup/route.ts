/**
 * One-time setup endpoint — creates the first store_admin.
 * Returns 409 if users already exist (setup already done).
 * Hit this once after deploy: POST /api/auth/setup
 * Body: { email, name, password }
 */
import { NextRequest, NextResponse } from "next/server";
import { countUsers, createUser } from "@/lib/users";

export async function POST(req: NextRequest) {
  try {
    const count = await countUsers();
    if (count > 0) {
      return NextResponse.json(
        { error: "Setup already complete. Use /admin/users to manage users." },
        { status: 409 }
      );
    }

    const { email, name, password } = await req.json();
    if (!email || !name || !password) {
      return NextResponse.json({ error: "email, name and password are required" }, { status: 400 });
    }
    if (password.length < 8) {
      return NextResponse.json({ error: "Password must be at least 8 characters" }, { status: 400 });
    }

    const user = await createUser({ email, name, password, role: "store_admin" });
    return NextResponse.json({ ok: true, user: { email: user.email, name: user.name, role: user.role } });
  } catch (err: unknown) {
    console.error("[setup]", err);
    const msg = err instanceof Error ? err.message : String(err);
    if (msg.includes("duplicate key") || msg.includes("E11000")) {
      return NextResponse.json({ error: "Email already exists" }, { status: 409 });
    }
    return NextResponse.json({ error: "Server error: " + msg }, { status: 500 });
  }
}

export async function GET() {
  const count = await countUsers();
  return NextResponse.json({ setupDone: count > 0, userCount: count });
}
