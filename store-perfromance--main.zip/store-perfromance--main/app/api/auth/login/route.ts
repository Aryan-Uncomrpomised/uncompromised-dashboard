import { NextRequest, NextResponse } from "next/server";
import { findByEmailOrUsername, verifyPassword, touchLastLogin } from "@/lib/users";
import { createSessionToken, SESSION_COOKIE } from "@/lib/session";

export async function POST(req: NextRequest) {
  try {
    const { email, username, password } = await req.json();
    const identifier = email || username;

    if (!identifier || !password) {
      return NextResponse.json({ error: "Email/username and password required" }, { status: 400 });
    }

    const user = await findByEmailOrUsername(identifier);
    if (!user) {
      return NextResponse.json({ error: "Invalid credentials" }, { status: 401 });
    }

    const valid = await verifyPassword(user, password);
    if (!valid) {
      return NextResponse.json({ error: "Invalid credentials" }, { status: 401 });
    }

    const token = await createSessionToken({
      sub:   user._id.toString(),
      email: user.email,
      name:  user.name,
      role:  user.role,
    });

    await touchLastLogin(user._id.toString());

    const res = NextResponse.json({ ok: true, role: user.role, name: user.name });
    res.cookies.set(SESSION_COOKIE, token, {
      httpOnly: true,
      sameSite: "lax",
      path:     "/",
      maxAge:   60 * 60 * 24 * 30, // 30 days
      secure:   process.env.NODE_ENV === "production",
    });
    return res;
  } catch (err) {
    console.error("[login]", err);
    return NextResponse.json({ error: "Server error" }, { status: 500 });
  }
}
