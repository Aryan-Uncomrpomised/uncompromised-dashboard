import { NextRequest, NextResponse } from "next/server";
import { fetchDashboardFromOdoo } from "@/lib/dashboard";
import { odoo } from "@/lib/odoo";
import { getCache, setCache, dashboardKey, managerDashboardKey } from "@/lib/redis";
import { verifySessionToken, SESSION_COOKIE } from "@/lib/session";
import { getOrderStatusMap } from "@/lib/mongo";

// Attach fresh MongoDB order statuses to any response
// This is NOT cached in Redis — always live so status changes reflect immediately
async function withStatuses(data: { orders: unknown[] }) {
  const ids = (data.orders as { id: number; source?: string; state?: string }[])
    .filter((o) => o.source === "website" && ["sale", "done"].includes(o.state ?? ""))
    .map((o) => o.id);
  const orderStatuses = await getOrderStatusMap(ids);
  return { ...data, orderStatuses };
}

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const from = searchParams.get("from") || "";
  const to   = searchParams.get("to")   || "";

  if (!from || !to) {
    return NextResponse.json({ error: "from and to are required" }, { status: 400 });
  }

  // Read role from JWT — no DB call needed
  const token     = req.cookies.get(SESSION_COOKIE)?.value;
  const session   = token ? await verifySessionToken(token) : null;
  const isManager = session?.role === "store_manager";

  // ── STORE MANAGER: orders only, 1 Odoo call ─────────────────────────────────
  if (isManager) {
    const cacheKey = managerDashboardKey(from, to);
    const cached   = await getCache<{ orders: unknown[] }>(cacheKey);
    const base     = cached ?? await (async () => {
      const rawOrders = await odoo.getOrdersInPeriod(from, to);
      const orders    = rawOrders.map((o) => ({ ...o, source: "website" as const }));
      const result    = { orders };
      await setCache(cacheKey, result);
      return result;
    })();
    const result = await withStatuses(base);
    return NextResponse.json(result, { headers: { "x-cache": cached ? "HIT" : "MISS" } });
  }

  // ── STORE ADMIN: full dashboard ──────────────────────────────────────────────
  const cacheKey = dashboardKey(from, to);
  const cached   = await getCache<{ orders: unknown[] }>(cacheKey);
  const base     = cached ?? await (async () => {
    const result = await fetchDashboardFromOdoo(from, to);
    await setCache(cacheKey, result);
    return result;
  })();
  const result = await withStatuses(base);
  return NextResponse.json(result, { headers: { "x-cache": cached ? "HIT" : "MISS" } });
}
