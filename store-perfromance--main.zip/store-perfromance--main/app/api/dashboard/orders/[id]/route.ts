import { NextRequest, NextResponse } from "next/server";
import { odoo } from "@/lib/odoo";
import { getCollection } from "@/lib/mongo";
import type { OrderStatus } from "@/app/api/orders/[id]/status/route";

interface OrderCache {
  odooId:    number;
  name:      string;
  detail:    unknown;
  lines:     unknown[];
  pickings:  unknown[];
  shippingAddress: unknown | null;
  cachedAt:  Date;
}

export async function GET(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;
  const orderId = parseInt(id, 10);
  if (isNaN(orderId)) return NextResponse.json({ error: "Invalid id" }, { status: 400 });

  try {
    const cacheCol  = await getCollection<OrderCache>("order_cache");
    const statusCol = await getCollection<OrderStatus>("order_status");

    const cached = await cacheCol.findOne({ odooId: orderId });
    // Use cache only if it has both pickings AND shippingAddress fields
    // (guards against old-format entries missing newly added fields)
    const isFresh = cached
      && Array.isArray(cached.pickings)
      && "shippingAddress" in cached;

    if (isFresh) {
      const orderStatus = await statusCol.findOne({ odooId: orderId });
      return NextResponse.json({
        order:           cached.detail,
        lines:           cached.lines            ?? [],
        pickings:        cached.pickings         ?? [],
        shippingAddress: cached.shippingAddress  ?? null,
        fromCache:       true,
        orderStatus:     orderStatus ?? null,
      });
    }

    // Cache miss — fetch order + lines + pickings in parallel
    const [orders, lines, pickings] = await Promise.all([
      odoo.getOrderById(orderId),
      odoo.getOrderLines(orderId),
      odoo.getPickingsByOrder(orderId),
    ]);
    if (!orders.length) return NextResponse.json({ error: "Not found" }, { status: 404 });

    const order = orders[0];

    // Fetch shipping address city — separate call since it's a related partner record
    const shippingPartnerId = Array.isArray(order.partner_shipping_id)
      ? (order.partner_shipping_id as [number, string])[0]
      : null;
    const shippingAddress = shippingPartnerId
      ? await odoo.getPartnerAddress(shippingPartnerId)
      : null;

    // Store everything in MongoDB (cached 15 min)
    await cacheCol.replaceOne(
      { odooId: orderId },
      { odooId: orderId, name: order.name, detail: order, lines, pickings, shippingAddress, cachedAt: new Date() },
      { upsert: true }
    );

    const orderStatus = await statusCol.findOne({ odooId: orderId });
    return NextResponse.json({
      order, lines, pickings, shippingAddress, fromCache: false, orderStatus: orderStatus ?? null,
    });

  } catch (err) {
    console.error("[order-detail]", err);
    return NextResponse.json({ error: String(err) }, { status: 500 });
  }
}
