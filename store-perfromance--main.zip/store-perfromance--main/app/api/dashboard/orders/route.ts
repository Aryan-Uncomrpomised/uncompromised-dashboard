import { NextRequest, NextResponse } from "next/server";
import { odoo } from "@/lib/odoo";

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const from = searchParams.get("from") || "";
  const to = searchParams.get("to") || "";

  try {
    const [orders, pickings] = await Promise.all([
      odoo.getOrdersInPeriod(from, to),
      odoo.getPickingsInPeriod(from, to),
    ]);
    const pendingPickings = pickings.filter((p) => ["confirmed", "assigned", "waiting"].includes(p.state));

    return NextResponse.json({ orders, pendingPickings });
  } catch (err) {
    console.error("[orders]", err);
    return NextResponse.json({ error: String(err) }, { status: 500 });
  }
}
