import { NextRequest, NextResponse } from "next/server";
import { verifySessionToken, SESSION_COOKIE } from "@/lib/session";
import { getCollection } from "@/lib/mongo";

interface Acknowledgement {
  odooId: number;
  orderName: string;
  acknowledgedBy: { id: string; name: string; email: string };
  acknowledgedAt: Date;
  note: string;
}

async function getUser(req: NextRequest) {
  const token = req.cookies.get(SESSION_COOKIE)?.value;
  if (!token) return null;
  return verifySessionToken(token);
}

// GET — check if order is acknowledged
export async function GET(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const user = await getUser(req);
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const { id } = await params;
  const odooId = parseInt(id, 10);
  if (isNaN(odooId)) return NextResponse.json({ error: "Invalid id" }, { status: 400 });

  const col = await getCollection<Acknowledgement>("order_acknowledgements");
  const ack = await col.findOne({ odooId });
  return NextResponse.json({ acknowledged: !!ack, acknowledgement: ack ?? null });
}

// POST — acknowledge an order
export async function POST(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const user = await getUser(req);
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const { id } = await params;
  const odooId = parseInt(id, 10);
  if (isNaN(odooId)) return NextResponse.json({ error: "Invalid id" }, { status: 400 });

  const body = await req.json().catch(() => ({}));
  const { orderName = "", note = "" } = body;

  const col = await getCollection<Acknowledgement>("order_acknowledgements");

  // Upsert — re-acknowledging updates the record
  const ack: Acknowledgement = {
    odooId,
    orderName,
    acknowledgedBy: { id: user.sub, name: user.name, email: user.email },
    acknowledgedAt: new Date(),
    note: String(note).trim(),
  };

  await col.replaceOne({ odooId }, ack, { upsert: true });
  return NextResponse.json({ ok: true, acknowledgement: ack });
}

// DELETE — remove acknowledgement (admin only)
export async function DELETE(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const user = await getUser(req);
  if (!user || user.role !== "store_admin") {
    return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  }

  const { id } = await params;
  const odooId = parseInt(id, 10);
  const col = await getCollection<Acknowledgement>("order_acknowledgements");
  await col.deleteOne({ odooId });
  return NextResponse.json({ ok: true });
}
