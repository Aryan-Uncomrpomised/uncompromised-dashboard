import { NextRequest, NextResponse } from "next/server";
import { verifySessionToken, SESSION_COOKIE } from "@/lib/session";
import { getCollection } from "@/lib/mongo";

export type StatusStep = "acknowledged" | "packed" | "shipped";

export interface TimelineEvent {
  status: StatusStep;
  by: { id: string; name: string; email: string };
  at: Date;
  note: string;
}

export interface OrderStatus {
  odooId: number;
  orderName: string;
  timeline: TimelineEvent[];
  updatedAt: Date;
}

// Status steps in order
const STEPS: StatusStep[] = ["acknowledged", "packed", "shipped"];

async function getUser(req: NextRequest) {
  const token = req.cookies.get(SESSION_COOKIE)?.value;
  if (!token) return null;
  return verifySessionToken(token);
}

const col = () => getCollection<OrderStatus>("order_status");

// GET — fetch full status + timeline for an order
export async function GET(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const user = await getUser(req);
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const { id } = await params;
  const odooId = parseInt(id, 10);
  if (isNaN(odooId)) return NextResponse.json({ error: "Invalid id" }, { status: 400 });

  const status = await (await col()).findOne({ odooId });
  return NextResponse.json({ status: status ?? null });
}

// POST — mark a step (acknowledged / packed / shipped)
export async function POST(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const user = await getUser(req);
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const { id } = await params;
  const odooId = parseInt(id, 10);
  if (isNaN(odooId)) return NextResponse.json({ error: "Invalid id" }, { status: 400 });

  const body = await req.json().catch(() => ({}));
  const { step, orderName = "", note = "" } = body as { step: StatusStep; orderName: string; note: string };

  if (!STEPS.includes(step)) {
    return NextResponse.json({ error: `step must be one of: ${STEPS.join(", ")}` }, { status: 400 });
  }

  const c = await col();
  const existing = await c.findOne({ odooId });

  // Prevent duplicate steps
  if (existing?.timeline.some((e) => e.status === step)) {
    return NextResponse.json({ error: `Already marked as ${step}` }, { status: 409 });
  }

  const event: TimelineEvent = {
    status: step,
    by:     { id: user.sub, name: user.name, email: user.email },
    at:     new Date(),
    note:   String(note).trim(),
  };

  await c.updateOne(
    { odooId },
    {
      $set:  { orderName, updatedAt: new Date() },
      $push: { timeline: event },
      $setOnInsert: { odooId },
    },
    { upsert: true }
  );

  const updated = await c.findOne({ odooId });
  return NextResponse.json({ ok: true, status: updated });
}

// DELETE — undo a step (admin only)
export async function DELETE(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const user = await getUser(req);
  if (!user || user.role !== "store_admin") {
    return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  }

  const { id } = await params;
  const odooId = parseInt(id, 10);
  const body = await req.json().catch(() => ({}));
  const { step } = body as { step: StatusStep };

  const c = await col();
  await c.updateOne({ odooId }, { $pull: { timeline: { status: step } } } as Parameters<typeof c.updateOne>[1]);

  const updated = await c.findOne({ odooId });
  return NextResponse.json({ ok: true, status: updated });
}
