import { NextRequest, NextResponse } from "next/server";
import { verifySessionToken, SESSION_COOKIE } from "@/lib/session";
import { getCollection } from "@/lib/mongo";
import { odoo } from "@/lib/odoo";
import { createShiprocketOrder } from "@/lib/shiprocket";

// Strip [SKU] prefix from product names
function stripSku(name: string): string {
  return name.replace(/^\[[^\]]+\]\s*/, "").trim();
}

// Split full name into first + last
function splitName(full: string): { first: string; last: string } {
  const parts = full.trim().split(/\s+/);
  if (parts.length === 1) return { first: parts[0], last: "." };
  return { first: parts[0], last: parts.slice(1).join(" ") };
}

// Clean Odoo state name: "Uttar Pradesh (IN)" → "Uttar Pradesh"
function cleanState(state: string): string {
  return state.replace(/\s*\(IN\)\s*$/, "").trim();
}

export async function POST(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  // Auth check
  const token   = req.cookies.get(SESSION_COOKIE)?.value;
  const session = token ? await verifySessionToken(token) : null;
  if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const { id } = await params;
  const orderId = parseInt(id, 10);
  if (isNaN(orderId)) return NextResponse.json({ error: "Invalid id" }, { status: 400 });

  try {
    // ── Fetch order from MongoDB cache (or Odoo if not cached) ───────────────
    const cacheCol = await getCollection<{
      odooId: number;
      detail: {
        id: number; name: string; state: string; date_order: string;
        amount_total: number; amount_untaxed: number;
        partner_id: [number, string];
        partner_shipping_id: [number, string] | false;
      };
      lines: {
        id: number; name: string; product_id: [number, string] | false;
        product_uom_qty: number; price_unit: number; price_subtotal: number;
      }[];
      shippingAddress: {
        street: string | false; street2: string | false;
        city: string | false; zip: string | false;
        state_id: [number, string] | false;
        country_id: [number, string] | false;
      } | null;
    }>("order_cache");

    const cached = await cacheCol.findOne({ odooId: orderId });
    if (!cached) return NextResponse.json({ error: "Order not found in cache. Open the order first to load it." }, { status: 404 });

    const { detail, lines, shippingAddress } = cached;

    if (!["sale", "done"].includes(detail.state)) {
      return NextResponse.json({ error: "Only confirmed orders can be sent to Shiprocket" }, { status: 400 });
    }

    // ── Fetch customer phone ─────────────────────────────────────────────────
    const customerId = detail.partner_id[0];
    const contact    = await odoo.getPartnerContact(customerId);
    const phone      = String(contact?.phone || "").replace(/\D/g, "").slice(-10);

    // ── Build shipping address ────────────────────────────────────────────────
    const addr     = shippingAddress;
    const city     = String(addr?.city     || "").trim();
    const pincode  = String(addr?.zip      || "").trim();
    const stateRaw = Array.isArray(addr?.state_id)   ? addr!.state_id[1]   : "";
    const stateName = cleanState(stateRaw);
    const street   = String(addr?.street   || "").trim();
    const street2  = String(addr?.street2  || "").trim();

    // ── Customer name ─────────────────────────────────────────────────────────
    const { first, last } = splitName(detail.partner_id[1]);

    // ── Order items — filter out zero-qty and service lines ──────────────────
    const orderItems = lines
      .filter((l) => l.product_uom_qty > 0 && l.price_unit > 0)
      .map((l) => ({
        name:          stripSku(l.product_id ? l.product_id[1] : l.name),
        sku:           l.product_id ? String(l.product_id[0]) : "N/A",
        units:         l.product_uom_qty,
        selling_price: l.price_unit,
      }));

    if (!orderItems.length) {
      return NextResponse.json({ error: "No valid order items to send" }, { status: 400 });
    }

    // ── Body from request (optional overrides: weight, dimensions) ───────────
    const body = await req.json().catch(() => ({}));

    const payload = {
      order_id:               detail.name,
      order_date:             detail.date_order.slice(0, 10),
      pickup_location:        process.env.SHIP_ROCKET_PICKUP || "Primary",
      billing_customer_name:  first,
      billing_last_name:      last,
      billing_address:        street  || "N/A",
      billing_address_2:      street2 || "",
      billing_city:           city    || "N/A",
      billing_pincode:        pincode || "000000",
      billing_state:          stateName || "N/A",
      billing_country:        "India",
      billing_email:          String(contact?.email || ""),
      billing_phone:          phone || "9999999999",
      shipping_is_billing:    true,
      payment_method:         "Prepaid",
      sub_total:              detail.amount_untaxed ?? detail.amount_total,
      length:                 body.length  ?? 10,
      width:                  body.width   ?? 10,
      height:                 body.height  ?? 10,
      weight:                 body.weight  ?? 0.5,
      order_items:            orderItems,
    };

    const result = await createShiprocketOrder(payload);

    return NextResponse.json({
      ok:                   true,
      shiprocket_order_id:  result.order_id,
      shipment_id:          result.shipment_id,
      channel_order_id:     result.channel_order_id,
      status:               result.status,
    });

  } catch (err) {
    console.error("[shiprocket]", err);
    return NextResponse.json({ error: String(err) }, { status: 500 });
  }
}
