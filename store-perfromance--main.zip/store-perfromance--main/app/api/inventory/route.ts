import { NextRequest, NextResponse } from "next/server";
import { odoo } from "@/lib/odoo";

// ── Pack size parser ──────────────────────────────────────────────────────────
// Parses "500 gms" → { label: "500 g", grams: 500 }
// Parses "5 kg"   → { label: "5 kg",  grams: 5000 }
function parsePackSize(str: string): { label: string; grams: number } | null {
  const m = str.trim().match(/^([\d.]+)\s*(kg|gms?|g|ml|l)s?$/i);
  if (!m) return null;
  const val  = parseFloat(m[1]);
  const unit = m[2].toLowerCase();
  if (unit === "kg")              return { label: `${val} kg`,  grams: val * 1000 };
  if (unit === "g" || unit.startsWith("gm")) return { label: val >= 1000 ? `${val/1000} kg` : `${val} g`, grams: val };
  if (unit === "l")               return { label: `${val} L`,   grams: val * 1000 };
  if (unit === "ml")              return { label: `${val} ml`,  grams: val };
  return null;
}

function formatWeight(grams: number): string {
  if (grams >= 1000) return `${parseFloat((grams / 1000).toFixed(2))} kg`;
  return `${grams} g`;
}

// Strip [SKU-CODE] prefix from Odoo product names e.g. "[UNC-KALA-CHANA-BLACK-GRAM-1KG] Kala Chana"
function stripSku(name: string): string {
  return name.replace(/^\[[^\]]+\]\s*/, "").trim();
}

// Known non-physical product keywords to exclude
const EXCLUDE_KEYWORDS = ["shipping", "delivery", "discount", "coupon", "fee", "charge"];

function isPhysical(name: string): boolean {
  const lower = name.toLowerCase();
  return !EXCLUDE_KEYWORDS.some((k) => lower.includes(k));
}

export interface InventoryVariant {
  packSize:     string;
  packSizeGrams: number;
  packCount:    number;
  totalGrams:   number;
  totalLabel:   string;
}

export interface InventoryProduct {
  name:        string;
  variants:    InventoryVariant[];
  totalGrams:  number;
  totalPacks:  number;
  totalLabel:  string;
}

export interface InventoryCategory {
  name:     string;
  products: InventoryProduct[];
}

export interface InventoryResult {
  categories:  InventoryCategory[];
  from:        string;
  to:          string;
  orderCount:  number;
  lineCount:   number;
}

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const from = searchParams.get("from") || "";
  const to   = searchParams.get("to")   || "";

  if (!from || !to) {
    return NextResponse.json({ error: "from and to are required" }, { status: 400 });
  }

  try {
    // ── 1. Fetch all confirmed order lines in the datetime range ─────────────
    const lines = await odoo.getOrderLinesForInventory(from, to);

    // Filter out non-physical products (shipping, discounts, etc.)
    const physicalLines = lines.filter((l) => isPhysical(stripSku(l.product_id[1])));

    if (!physicalLines.length) {
      return NextResponse.json({ categories: [], from, to, orderCount: 0, lineCount: 0 });
    }

    // ── 2. Get unique product IDs and fetch variant details ──────────────────
    const productIds = [...new Set(physicalLines.map((l) => l.product_id[0]))];
    const variants   = await odoo.getProductVariants(productIds);

    // ── 3. Get pack size attribute values ────────────────────────────────────
    const allAttrValueIds = [...new Set(variants.flatMap((v) => v.product_template_attribute_value_ids))];
    const packSizeValues  = await odoo.getPackSizeValues(allAttrValueIds);
    const packSizeMap     = new Map(packSizeValues.map((p) => [p.id, p.name])); // attrValueId → "500 gms"

    // ── 4. Get product templates with public categories ──────────────────────
    const templateIds  = [...new Set(variants.map((v) => v.product_tmpl_id[0]))];
    const [templates, publicCategories] = await Promise.all([
      odoo.getProductTemplatesWithCategories(templateIds),
      odoo.getPublicCategories(),
    ]);

    const categoryMap  = new Map(publicCategories.map((c) => [c.id, c.name])); // catId → name
    const templateMap  = new Map(templates.map((t) => [t.id, t]));             // tmplId → template
    const variantMap   = new Map(variants.map((v) => [v.id, v]));              // productId → variant

    // ── 5. Aggregate ─────────────────────────────────────────────────────────
    // Accumulator: category → product → packSize → count
    type Acc = Map<string, Map<string, Map<string, { grams: number; count: number }>>>;
    const acc: Acc = new Map();

    for (const line of physicalLines) {
      const variant  = variantMap.get(line.product_id[0]);
      if (!variant) continue;

      const tmpl     = templateMap.get(variant.product_tmpl_id[0]);
      const tmplName = stripSku(variant.product_tmpl_id[1]);

      // Category: first public category or "Other"
      const catId    = tmpl?.public_categ_ids?.[0];
      const catName  = catId ? (categoryMap.get(catId) ?? "Other") : "Other";

      // Pack size: find the Pack Size attribute value for this variant
      const packAttrId  = variant.product_template_attribute_value_ids
        .find((id) => packSizeMap.has(id));
      const packSizeStr = packAttrId ? (packSizeMap.get(packAttrId) ?? "") : "";
      const parsed      = parsePackSize(packSizeStr);
      const packLabel   = parsed?.label ?? (packSizeStr || line.product_id[1]);
      const packGrams   = parsed?.grams ?? 0;

      if (!acc.has(catName))         acc.set(catName, new Map());
      if (!acc.get(catName)!.has(tmplName)) acc.get(catName)!.set(tmplName, new Map());

      const prodMap = acc.get(catName)!.get(tmplName)!;
      const key     = packLabel;
      const existing = prodMap.get(key) ?? { grams: packGrams, count: 0 };
      existing.count += line.product_uom_qty;
      prodMap.set(key, existing);
    }

    // ── 6. Build output ──────────────────────────────────────────────────────
    const categories: InventoryCategory[] = [];

    for (const [catName, products] of [...acc.entries()].sort(([a], [b]) => a.localeCompare(b))) {
      const productList: InventoryProduct[] = [];

      for (const [prodName, packs] of [...products.entries()].sort(([a], [b]) => a.localeCompare(b))) {
        const variantList: InventoryVariant[] = [];
        let totalGrams = 0;
        let totalPacks = 0;

        for (const [packSizeLabel, { grams, count }] of packs.entries()) {
          const lineTotal = grams * count;
          variantList.push({
            packSize:      packSizeLabel,
            packSizeGrams: grams,
            packCount:     count,
            totalGrams:    lineTotal,
            totalLabel:    formatWeight(lineTotal),
          });
          totalGrams += lineTotal;
          totalPacks += count;
        }

        // Sort variants by pack size ascending
        variantList.sort((a, b) => a.packSizeGrams - b.packSizeGrams);

        productList.push({
          name:       prodName,
          variants:   variantList,
          totalGrams,
          totalPacks,
          totalLabel: totalGrams > 0 ? formatWeight(totalGrams) : `${totalPacks} pcs`,
        });
      }

      categories.push({ name: catName, products: productList });
    }

    return NextResponse.json({
      categories,
      from,
      to,
      orderCount: [...new Set(physicalLines.map((l) => (l as { product_id: [number,string]; product_uom_qty: number; order_id?: number }).order_id))].length,
      lineCount:  physicalLines.length,
    });

  } catch (err) {
    console.error("[inventory]", err);
    return NextResponse.json({ error: String(err) }, { status: 500 });
  }
}
