import { NextRequest, NextResponse } from "next/server";
import { format, subDays, startOfMonth } from "date-fns";
import { fetchDashboardFromOdoo } from "@/lib/dashboard";
import { setCache, dashboardKey, managerDashboardKey, setLastRefresh } from "@/lib/redis";

function isAuthorized(req: NextRequest) {
  const secret = process.env.CRON_SECRET;
  if (!secret) return true;
  return req.headers.get("authorization") === `Bearer ${secret}`;
}

export async function GET(req: NextRequest) {
  if (!isAuthorized(req)) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const today = format(new Date(), "yyyy-MM-dd");
  const ranges = [
    { from: today,                                           to: today, label: "today" },
    { from: format(subDays(new Date(), 6),   "yyyy-MM-dd"), to: today, label: "last_7_days" },
    { from: format(subDays(new Date(), 29),  "yyyy-MM-dd"), to: today, label: "last_30_days" },
    { from: format(startOfMonth(new Date()), "yyyy-MM-dd"), to: today, label: "this_month" },
  ];

  const results = await Promise.allSettled(
    ranges.map(async ({ from, to, label }) => {
      const data = await fetchDashboardFromOdoo(from, to);

      // Warm admin cache (full data)
      await setCache(dashboardKey(from, to), data);

      // Warm manager cache from the same fetch — zero extra Odoo calls
      const managerData = { orders: data.orders };
      await setCache(managerDashboardKey(from, to), managerData);

      return label;
    })
  );

  const anySuccess = results.some((r) => r.status === "fulfilled");
  if (anySuccess) await setLastRefresh();

  const summary = results.map((r, i) => ({
    range: ranges[i].label,
    status: r.status,
    ...(r.status === "rejected" ? { error: String((r as PromiseRejectedResult).reason) } : {}),
  }));

  console.log("[cron/refresh]", summary);
  return NextResponse.json({ refreshed: summary, at: new Date().toISOString() });
}
