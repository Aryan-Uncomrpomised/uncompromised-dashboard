"use client";

import { useEffect, useState, useCallback } from "react";
import { useRouter } from "next/navigation";
import { format, subDays } from "date-fns";
import {
  ShoppingCart, Users, UserPlus, RefreshCw, TrendingUp,
  Package, Truck, Clock, Globe, IndianRupee, BarChart3,
  Star, ListOrdered, LogOut, Store, Settings, ClipboardList,
} from "lucide-react";
import type { UserRole } from "@/lib/session";
import { KPICard } from "@/components/KPICard";
import { SalesTrendChart } from "@/components/SalesTrendChart";
import { CustomerChart } from "@/components/CustomerChart";
import { OrdersTable } from "@/components/OrdersTable";
import { OrderDetailDrawer } from "@/components/OrderDetailDrawer";
import { DateRangePicker, type DateRange } from "@/components/DateRangePicker";
import { formatINR, formatNumber } from "@/lib/utils";

type Source = "all" | "website" | "pos";

type KPIData = {
  combined: {
    totalRevenue: number; orderCount: number; avgOrderValue: number;
    totalCustomers: number; newCustomers: number; repeatCustomers: number;
    totalDeliveryFund: number;
  };
  website: {
    visitors: number; cartAdds: number; cartValue: number;
    orderCount: number; avgOrderValue: number;
    newCustomers: number; repeatCustomers: number;
    totalRevenue: number; totalCustomers: number; totalDeliveryFund: number;
  };
  pos: {
    totalRevenue: number; orderCount: number; avgOrderValue: number;
    newCustomers: number; repeatCustomers: number;
    totalCustomers: number; walkInOrders: number;
  };
  logistics: { dispatched: number; pending: number };
};

type TrendPoint = {
  date: string; label: string;
  revenue: number; orders: number;
  posRevenue: number; posOrders: number;
};

type Order = {
  id: number; name: string; state: string; date_order: string;
  amount_total: number; amount_delivery: number;
  partner_id: [number, string]; invoice_status: string;
  delivery_status: string | false; source?: "website" | "pos";
};

function SectionTitle({ icon: Icon, title, subtitle }: { icon: React.ElementType; title: string; subtitle?: string }) {
  return (
    <div className="flex items-center gap-3 mb-5">
      <div className="p-2 bg-slate-100 rounded-xl">
        <Icon className="w-5 h-5 text-slate-600" />
      </div>
      <div>
        <h2 className="text-base font-semibold text-slate-800">{title}</h2>
        {subtitle && <p className="text-xs text-slate-400">{subtitle}</p>}
      </div>
    </div>
  );
}

function Card({ children, className = "" }: { children: React.ReactNode; className?: string }) {
  return (
    <div className={`bg-white rounded-2xl border border-slate-200 shadow-sm p-4 sm:p-6 ${className}`}>
      {children}
    </div>
  );
}

function SourceToggle({ value, onChange }: { value: Source; onChange: (s: Source) => void }) {
  const options: { key: Source; label: string }[] = [
    { key: "all",     label: "All" },
    { key: "website", label: "Website" },
    { key: "pos",     label: "POS" },
  ];
  return (
    <div className="flex items-center gap-1 bg-slate-100 rounded-xl p-1 w-full sm:w-auto">
      {options.map(({ key, label }) => (
        <button
          key={key}
          onClick={() => onChange(key)}
          className={`flex-1 sm:flex-none px-4 py-1.5 text-xs font-medium rounded-lg transition-colors ${
            value === key ? "bg-white shadow-sm text-slate-800" : "text-slate-500 hover:text-slate-700"
          }`}
        >
          {label}
        </button>
      ))}
    </div>
  );
}

export default function Dashboard() {
  const router = useRouter();

  async function handleLogout() {
    await fetch("/api/auth/logout", { method: "POST" });
    router.push("/login");
    router.refresh();
  }

  const adminDefault: DateRange = {
    from: format(subDays(new Date(), 6), "yyyy-MM-dd"),
    to:   format(new Date(), "yyyy-MM-dd"),
    label: "Last 7 days",
  };
  const managerDefault: DateRange = {
    from: format(subDays(new Date(), 29), "yyyy-MM-dd"),
    to:   format(new Date(), "yyyy-MM-dd"),
    label: "Last 30 days",
  };

  const [role, setRole]             = useState<UserRole | null>(null);
  const [userName, setUserName]     = useState<string>("");
  const [dateRange, setDateRange]   = useState<DateRange>(adminDefault);
  const [source, setSource]         = useState<Source>("all");
  const [kpis, setKpis]                       = useState<KPIData | null>(null);
  const [trend, setTrend]                     = useState<TrendPoint[]>([]);
  const [orders, setOrders]                   = useState<Order[]>([]);
  const [orderStatuses, setOrderStatuses]     = useState<Record<number, string>>({});
  const [loading,      setLoading]      = useState(true);
  const [roleLoaded,   setRoleLoaded]   = useState(false);
  const [lastRefresh,  setLastRefresh]  = useState<Date>(new Date());
  const [activeTab,    setActiveTab]    = useState<"all" | "confirmed" | "pending">("confirmed");
  const [selectedOrder, setSelectedOrder] = useState<{ id: number; name: string } | null>(null);

  // Step 1: fetch role FIRST, set the correct date range, THEN trigger data load
  useEffect(() => {
    fetch("/api/auth/me")
      .then((r) => r.json())
      .then((d) => {
        if (d.role) {
          setRole(d.role);
          setUserName(d.name);
          // Set range before marking role loaded — avoids double fetch
          if (d.role === "store_manager") {
            setDateRange(managerDefault);
          }
        }
      })
      .catch(() => {})
      .finally(() => setRoleLoaded(true)); // triggers data fetch exactly once
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Silently prefetch order details into MongoDB cache so clicks are instant
  const prefetchOrders = useCallback((orderList: Order[]) => {
    const toFetch = orderList
      .filter((o) => o.source === "website" && ["sale", "done"].includes(o.state))
      .slice(0, 5);
    // Fire-and-forget — no await, no state update, just warm the cache
    toFetch.forEach((o) => {
      fetch(`/api/dashboard/orders/${o.id}`).catch(() => {});
    });
  }, []);

  const fetchData = useCallback(async (range: DateRange) => {
    setLoading(true);
    try {
      const params = new URLSearchParams({ from: range.from, to: range.to });
      const res = await fetch(`/api/dashboard?${params}`).then((r) => r.json());
      if (res?.kpis?.combined) setKpis(res.kpis);
      setTrend(res?.trend || []);
      const orderList = res?.orders || [];
      setOrders(orderList);
      setOrderStatuses(res?.orderStatuses || {});
      setLastRefresh(new Date());
      // Start prefetching order details in background after data loads
      prefetchOrders(orderList);
    } finally {
      setLoading(false);
    }
  }, [prefetchOrders]);

  // Step 2: only fetch data after role is known (prevents 7-day flash for managers)
  useEffect(() => {
    if (roleLoaded) fetchData(dateRange);
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [dateRange, roleLoaded]);

  const handleRefresh = () => fetchData(dateRange);

  // ── Derive displayed KPIs from selected source ─────────────────────────────
  const storeKpis = (() => {
    if (!kpis) return null;
    if (source === "website") return {
      totalRevenue: kpis.website.totalRevenue,
      orderCount: kpis.website.orderCount,
      avgOrderValue: kpis.website.avgOrderValue,
      newCustomers: kpis.website.newCustomers,
      repeatCustomers: kpis.website.repeatCustomers,
      totalCustomers: kpis.website.totalCustomers,
      totalDeliveryFund: kpis.website.totalDeliveryFund,
    };
    if (source === "pos") return {
      totalRevenue: kpis.pos.totalRevenue,
      orderCount: kpis.pos.orderCount,
      avgOrderValue: kpis.pos.avgOrderValue,
      newCustomers: kpis.pos.newCustomers,
      repeatCustomers: kpis.pos.repeatCustomers,
      totalCustomers: kpis.pos.totalCustomers,
      totalDeliveryFund: 0,
    };
    // "all" — combined across both channels; new + repeat = totalCustomers ✓
    return {
      totalRevenue:      kpis.combined.totalRevenue,
      orderCount:        kpis.combined.orderCount,
      avgOrderValue:     kpis.combined.avgOrderValue,
      newCustomers:      kpis.combined.newCustomers,
      repeatCustomers:   kpis.combined.repeatCustomers,
      totalCustomers:    kpis.combined.totalCustomers,
      totalDeliveryFund: kpis.combined.totalDeliveryFund,
    };
  })();

  // ── Filter orders by source and status tab ────────────────────────────────
  // Managers always see website-only orders regardless of source toggle
  const effectiveSource = role === "store_manager" ? "website" : source;

  // Count unacknowledged confirmed website orders (across ALL orders, not just current page)
  const unacknowledgedCount = orders.filter(
    (o) => o.source === "website" && ["sale", "done"].includes(o.state) && !orderStatuses[o.id]
  ).length;
  const filteredOrders = orders.filter((o) => {
    if (effectiveSource === "website" && o.source !== "website") return false;
    if (effectiveSource === "pos"     && o.source !== "pos")     return false;
    // "confirmed" tab: website confirmed states + POS confirmed states
    if (activeTab === "confirmed") return ["sale", "done", "paid", "invoiced"].includes(o.state);
    // "pending" tab: website carts/drafts only — POS drafts are open terminal sessions, not carts
    if (activeTab === "pending")   return o.source === "website" && o.state === "draft";
    return true;
  });

  // Only website orders are clickable (POS has no detail endpoint yet)
  const handleRowClick = (o: Order) => {
    if (o.source === "pos") return;
    setSelectedOrder({ id: o.id, name: o.name });
  };

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Header */}
      <header className="bg-white border-b border-slate-200 sticky top-0 z-40">
        <div className="max-w-screen-2xl mx-auto px-4 sm:px-6">
          {/* Row 1 — logo + actions */}
          <div className="flex items-center justify-between gap-2 py-3">
            <div className="flex items-center gap-2.5">
              <img src="/logo.svg" alt="Uncompromised" className="w-8 h-8 rounded-xl" />
              <div>
                <h1 className="text-sm font-bold text-slate-900 leading-tight">Uncompromised</h1>
                <p className="text-xs text-slate-400 leading-tight">Store Dashboard</p>
              </div>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="text-xs text-slate-400 hidden md:block" suppressHydrationWarning>
                Updated {format(lastRefresh, "HH:mm:ss")}
              </span>
              <button
                onClick={handleRefresh}
                disabled={loading}
                className="p-2 text-slate-500 hover:text-slate-900 hover:bg-slate-100 rounded-xl transition-colors disabled:opacity-50"
                title="Refresh"
              >
                <RefreshCw className={`w-4 h-4 ${loading ? "animate-spin" : ""}`} />
              </button>
              <DateRangePicker value={dateRange} onChange={setDateRange} />
              <button
                onClick={() => router.push("/inventory")}
                className="p-2 text-slate-500 hover:text-slate-800 hover:bg-slate-100 rounded-xl transition-colors"
                title="Inventory requirements"
              >
                <ClipboardList className="w-4 h-4" />
              </button>
              {role === "store_admin" && (
                <>
                  <button
                    onClick={() => router.push("/top-products")}
                    className="p-2 text-slate-500 hover:text-slate-800 hover:bg-slate-100 rounded-xl transition-colors"
                    title="Top selling products"
                  >
                    <Star className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => router.push("/admin/users")}
                    className="p-2 text-slate-500 hover:text-slate-800 hover:bg-slate-100 rounded-xl transition-colors"
                    title="Manage users"
                  >
                    <Settings className="w-4 h-4" />
                  </button>
                </>
              )}
              <button
                onClick={handleLogout}
                className="p-2 text-slate-500 hover:text-red-600 hover:bg-red-50 rounded-xl transition-colors"
                title={`Sign out${userName ? ` (${userName})` : ""}`}
              >
                <LogOut className="w-4 h-4" />
              </button>
            </div>
          </div>
          {/* Row 2 — source toggle (full width on mobile) */}
          <div className="pb-3">
            <SourceToggle value={source} onChange={setSource} />
          </div>
        </div>
      </header>

      <main className="max-w-screen-2xl mx-auto px-4 sm:px-6 py-5 sm:py-8 space-y-6 sm:space-y-8">

        {/* ── MANAGER NOTICE BANNER ── */}
        {role === "store_manager" && (
          <div className="bg-blue-50 border border-blue-100 rounded-2xl px-5 py-3 flex items-center gap-3">
            <div className="w-2 h-2 rounded-full bg-blue-500 shrink-0" />
            <p className="text-sm text-blue-700">
              Store Manager view · Showing website orders only · Acknowledge orders as you process them
            </p>
          </div>
        )}

        {/* ── ADMIN-ONLY SECTIONS ── */}
        {role === "store_admin" && (
        <>
        <section>
          <SectionTitle
            icon={source === "pos" ? Store : source === "website" ? Globe : ShoppingCart}
            title={source === "pos" ? "POS Performance" : source === "website" ? "Website Performance" : "Store Performance (All Channels)"}
            subtitle={source === "pos" ? "Point of Sale orders" : source === "website" ? "Online orders" : "Website + POS combined"}
          />
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3 sm:gap-4">
            <KPICard
              title="Total Revenue"
              value={storeKpis ? formatINR(storeKpis.totalRevenue) : "—"}
              icon={IndianRupee}
              iconColor="text-emerald-600"
              subtitle={`${storeKpis?.orderCount ?? 0} confirmed orders`}
              loading={loading}
            />
            <KPICard
              title="Avg Order Value"
              value={storeKpis ? formatINR(storeKpis.avgOrderValue) : "—"}
              icon={TrendingUp}
              iconColor="text-blue-600"
              loading={loading}
            />
            <KPICard
              title="Total Customers"
              value={storeKpis ? formatNumber(storeKpis.totalCustomers) : "—"}
              icon={Users}
              iconColor="text-purple-600"
              subtitle="Unique buyers in period"
              loading={loading}
            />
            <KPICard
              title="New Customers"
              value={storeKpis ? formatNumber(storeKpis.newCustomers) : "—"}
              icon={UserPlus}
              iconColor="text-brand-600"
              subtitle="First-time buyers"
              loading={loading}
            />
            <KPICard
              title="Repeat Customers"
              value={storeKpis ? formatNumber(storeKpis.repeatCustomers) : "—"}
              icon={Star}
              iconColor="text-amber-500"
              subtitle="Returning buyers"
              loading={loading}
            />
          </div>
        </section>

        {/* ── WEBSITE ANALYTICS — hidden when POS-only ── */}
        {source !== "pos" && (
          <section>
            <SectionTitle icon={Globe} title="Website & Cart Analytics" subtitle="shop.uncompromised.in" />
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-7 gap-3 sm:gap-4">
              <KPICard title="Visitors"        value={kpis?.website ? formatNumber(kpis.website.visitors)  : "—"} icon={Globe}         iconColor="text-sky-600"    loading={loading} />
              <KPICard title="Active Carts"    value={kpis?.website ? formatNumber(kpis.website.cartAdds)  : "—"} icon={ShoppingCart}  iconColor="text-orange-500" loading={loading} />
              <KPICard title="Cart Value"      value={kpis?.website ? formatINR(kpis.website.cartValue)    : "—"} icon={IndianRupee}   iconColor="text-orange-600" subtitle="In active carts" loading={loading} />
              <KPICard title="Orders Placed"   value={kpis?.website ? formatNumber(kpis.website.orderCount): "—"} icon={ListOrdered}   iconColor="text-emerald-600" loading={loading} />
              <KPICard title="Avg Order Value" value={kpis?.website ? formatINR(kpis.website.avgOrderValue): "—"} icon={BarChart3}     iconColor="text-blue-600"   loading={loading} />
              <KPICard title="New Customers"   value={kpis?.website ? formatNumber(kpis.website.newCustomers):  "—"} icon={UserPlus}  iconColor="text-brand-600"  loading={loading} />
              <KPICard title="Repeat Customers"value={kpis?.website ? formatNumber(kpis.website.repeatCustomers):"—"} icon={Star}    iconColor="text-amber-500"  loading={loading} />
            </div>
          </section>
        )}

        {/* ── POS SNAPSHOT — shown when all or pos ── */}
        {source !== "website" && kpis?.pos && (
          <section>
            <SectionTitle icon={Store} title="POS Analytics" subtitle="Physical store sales" />
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
              <KPICard title="POS Revenue"      value={formatINR(kpis.pos.totalRevenue)}          icon={IndianRupee} iconColor="text-orange-600" loading={loading} />
              <KPICard title="POS Orders"       value={formatNumber(kpis.pos.orderCount)}          icon={ListOrdered} iconColor="text-orange-500" loading={loading} />
              <KPICard title="POS Avg Order"    value={formatINR(kpis.pos.avgOrderValue)}          icon={BarChart3}   iconColor="text-amber-600"  loading={loading} />
              <KPICard title="Known Customers"  value={formatNumber(kpis.pos.totalCustomers)}      icon={Users}       iconColor="text-purple-600" subtitle={`+${kpis.pos.walkInOrders} walk-in`} loading={loading} />
            </div>
          </section>
        )}

        {/* ── DELIVERY FUND + LOGISTICS — hidden for POS-only ── */}
        {source !== "pos" && (
          <section>
            <SectionTitle icon={Truck} title="Delivery & Logistics" />
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
              <KPICard
                title="Delivery Fund Recognised"
                value={storeKpis ? formatINR(storeKpis.totalDeliveryFund) : "—"}
                icon={IndianRupee}
                iconColor="text-teal-600"
                subtitle="Total delivery charges collected"
                loading={loading}
              />
              <KPICard
                title="Dispatched Orders"
                value={kpis?.logistics ? formatNumber(kpis.logistics.dispatched) : "—"}
                icon={Truck}
                iconColor="text-emerald-600"
                subtitle="Completed in period"
                loading={loading}
              />
              <KPICard
                title="Pending Dispatch"
                value={kpis?.logistics ? formatNumber(kpis.logistics.pending) : "—"}
                icon={Clock}
                iconColor="text-amber-500"
                subtitle="Scheduled, not yet dispatched"
                loading={loading}
              />
            </div>
          </section>
        )}

        {/* ── COMBINED CUSTOMER SUMMARY ── */}
        {storeKpis && (
          <section className="bg-gradient-to-r from-brand-600 to-emerald-500 rounded-2xl p-6 text-white shadow-lg">
            <h3 className="text-sm font-semibold text-emerald-100 mb-4 uppercase tracking-wider">
              Customer Summary — {source === "all" ? "All Channels" : source === "website" ? "Website" : "POS"}
            </h3>
            <div className="grid grid-cols-3 gap-6">
              <div>
                <div className="text-3xl font-bold">{formatNumber(storeKpis.newCustomers)}</div>
                <div className="text-sm text-emerald-200 mt-1">New Customers</div>
              </div>
              <div>
                <div className="text-3xl font-bold">{formatNumber(storeKpis.repeatCustomers)}</div>
                <div className="text-sm text-emerald-200 mt-1">Repeat Customers</div>
              </div>
              <div>
                <div className="text-3xl font-bold">{formatINR(storeKpis.avgOrderValue)}</div>
                <div className="text-sm text-emerald-200 mt-1">Average Order Value</div>
              </div>
            </div>
          </section>
        )}

        {/* ── CHARTS ROW ── */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <Card className="lg:col-span-2">
            <SectionTitle icon={TrendingUp} title="Sales Trend" subtitle="Revenue & order volume over time" />
            <SalesTrendChart data={trend} source={source} loading={loading} />
          </Card>
          <Card>
            <SectionTitle icon={Users} title="Customer Mix" subtitle="New vs repeat buyers" />
            <CustomerChart
              newCustomers={storeKpis?.newCustomers ?? 0}
              repeatCustomers={storeKpis?.repeatCustomers ?? 0}
              loading={loading}
            />
            {storeKpis && !loading && (
              <div className="mt-4 grid grid-cols-2 gap-3 text-center">
                <div className="bg-emerald-50 rounded-xl p-3">
                  <div className="text-xl font-bold text-emerald-700">{storeKpis.newCustomers}</div>
                  <div className="text-xs text-emerald-600 mt-0.5">New</div>
                </div>
                <div className="bg-blue-50 rounded-xl p-3">
                  <div className="text-xl font-bold text-blue-700">{storeKpis.repeatCustomers}</div>
                  <div className="text-xs text-blue-600 mt-0.5">Repeat</div>
                </div>
              </div>
            )}
          </Card>
        </div>

        </>
        )}{/* end admin-only sections */}

        {/* ── ORDERS TABLE ── */}
        <Card>
          <div className="flex flex-wrap items-center justify-between gap-3 mb-5">
            <SectionTitle
              icon={Package}
              title="Orders"
              subtitle={`${filteredOrders.length} orders${source !== "all" ? ` · ${source === "pos" ? "POS" : "Website"} only` : ""}`}
            />
            <div className="flex items-center gap-2">
              <div className="flex items-center gap-1 bg-slate-100 rounded-xl p-1">
                {(["all", "confirmed", "pending"] as const).map((tab) => (
                  <button
                    key={tab}
                    onClick={() => setActiveTab(tab)}
                    className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-colors capitalize ${
                      activeTab === tab ? "bg-white shadow-sm text-slate-800" : "text-slate-500 hover:text-slate-700"
                    }`}
                  >
                    {tab === "confirmed" ? "Confirmed" : tab === "pending" ? "Draft/Cart" : "All"}
                  </button>
                ))}
              </div>
            </div>
          </div>
          <OrdersTable
            orders={filteredOrders}
            orderStatuses={orderStatuses}
            loading={loading}
            onRowClick={handleRowClick}
          />
        </Card>

      </main>

      <footer className="max-w-screen-2xl mx-auto px-4 sm:px-6 py-6 text-center text-xs text-slate-400">
        Uncompromised Analytics · Powered by Odoo · shop.uncompromised.in · {new Date().getFullYear()}
      </footer>

      <OrderDetailDrawer
        orderId={selectedOrder?.id ?? null}
        orderName={selectedOrder?.name}
        onClose={() => setSelectedOrder(null)}
        canAct={role === "store_manager"}
      />
    </div>
  );
}
