"use client";

import { useState, useRef } from "react";
import { useRouter } from "next/navigation";
import { format, subDays } from "date-fns";
import { ArrowLeft, Download, Package, RefreshCw, ChevronDown, ChevronRight } from "lucide-react";
import type { InventoryResult, InventoryCategory } from "@/app/api/inventory/route";

// ── Helpers ───────────────────────────────────────────────────────────────────
function toLocalDatetimeInput(date: Date): string {
  const pad = (n: number) => String(n).padStart(2, "0");
  return `${date.getFullYear()}-${pad(date.getMonth()+1)}-${pad(date.getDate())}T${pad(date.getHours())}:${pad(date.getMinutes())}`;
}

function toOdooDatetime(localStr: string): string {
  // Convert local datetime-input value to UTC string for Odoo
  const d = new Date(localStr);
  return d.toISOString().replace("T", " ").slice(0, 19);
}

function defaultFrom(): string {
  const d = new Date();
  d.setHours(19, 0, 0, 0);
  d.setDate(d.getDate() - 1);
  return toLocalDatetimeInput(d);
}
function defaultTo(): string {
  const d = new Date();
  d.setHours(19, 0, 0, 0);
  return toLocalDatetimeInput(d);
}

const CATEGORY_COLORS: Record<string, string> = {
  Flour:                 "bg-amber-100 text-amber-800 border-amber-200",
  Lentils:               "bg-orange-100 text-orange-800 border-orange-200",
  Grains:                "bg-yellow-100 text-yellow-800 border-yellow-200",
  Spices:                "bg-red-100 text-red-800 border-red-200",
  Oil:                   "bg-lime-100 text-lime-800 border-lime-200",
  Vegetables:            "bg-green-100 text-green-800 border-green-200",
  Fruits:                "bg-pink-100 text-pink-800 border-pink-200",
  Seeds:                 "bg-teal-100 text-teal-800 border-teal-200",
  Pickle:                "bg-purple-100 text-purple-800 border-purple-200",
  "Chutney/Jam":         "bg-rose-100 text-rose-800 border-rose-200",
  "Exotic Vegetables":   "bg-emerald-100 text-emerald-800 border-emerald-200",
  "Minimally Processed": "bg-cyan-100 text-cyan-800 border-cyan-200",
  "Farm Sourced":        "bg-indigo-100 text-indigo-800 border-indigo-200",
  Other:                 "bg-slate-100 text-slate-700 border-slate-200",
};

function categoryColor(name: string) {
  return CATEGORY_COLORS[name] ?? CATEGORY_COLORS.Other;
}

// ── Components ────────────────────────────────────────────────────────────────
function CategoryBlock({ cat }: { cat: InventoryCategory }) {
  const [open, setOpen] = useState(true);
  const clr = categoryColor(cat.name);

  return (
    <div className="border border-slate-200 rounded-2xl overflow-hidden">
      <button
        onClick={() => setOpen((o) => !o)}
        className={`w-full flex items-center justify-between px-5 py-3 border ${clr} font-semibold text-sm`}
      >
        <span>{cat.name}</span>
        <span className="flex items-center gap-3">
          <span className="text-xs font-normal opacity-70">
            {cat.products.length} product{cat.products.length !== 1 ? "s" : ""}
          </span>
          {open ? <ChevronDown className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
        </span>
      </button>

      {open && (
        <div className="divide-y divide-slate-50">
          {cat.products.map((p) => (
            <div key={p.name} className="px-5 py-4">
              <div className="flex items-start justify-between gap-2 mb-2">
                <span className="font-semibold text-slate-800 text-sm">{p.name}</span>
                <span className="text-xs font-bold text-slate-700 bg-slate-100 px-2.5 py-1 rounded-xl whitespace-nowrap">
                  {p.totalLabel}
                  <span className="font-normal text-slate-500 ml-1">· {p.totalPacks} packs</span>
                </span>
              </div>
              <div className="space-y-1">
                {p.variants.map((v) => (
                  <div key={v.packSize} className="flex items-center justify-between text-xs text-slate-500 pl-3">
                    <span>{v.packSize}</span>
                    <span className="flex items-center gap-2">
                      <span className="text-slate-400">{v.packCount} × {v.packSize}</span>
                      <span className="font-medium text-slate-700">{v.totalLabel}</span>
                    </span>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

// ── Main Page ─────────────────────────────────────────────────────────────────
export default function InventoryPage() {
  const router  = useRouter();
  const printRef = useRef<HTMLDivElement>(null);

  const [from,    setFrom]    = useState(defaultFrom());
  const [to,      setTo]      = useState(defaultTo());
  const [result,  setResult]  = useState<InventoryResult | null>(null);
  const [loading, setLoading] = useState(false);
  const [error,   setError]   = useState("");

  async function generate() {
    setLoading(true);
    setError("");
    setResult(null);
    try {
      const params = new URLSearchParams({
        from: toOdooDatetime(from),
        to:   toOdooDatetime(to),
      });
      const res  = await fetch(`/api/inventory?${params}`);
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Failed");
      setResult(data);
    } catch (e) {
      setError(e instanceof Error ? e.message : String(e));
    } finally {
      setLoading(false);
    }
  }

  async function downloadPNG() {
    if (!printRef.current) return;
    const html2canvas = (await import("html2canvas")).default;
    const canvas = await html2canvas(printRef.current, {
      backgroundColor: "#ffffff",
      scale: 2,
      useCORS: true,
    });
    const link = document.createElement("a");
    link.download = `inventory-${from.slice(0,10)}-to-${to.slice(0,10)}.png`;
    link.href = canvas.toDataURL("image/png");
    link.click();
  }

  const fromLabel = from ? new Date(from).toLocaleString("en-IN", { day:"2-digit", month:"short", hour:"2-digit", minute:"2-digit", hour12: true }) : "";
  const toLabel   = to   ? new Date(to  ).toLocaleString("en-IN", { day:"2-digit", month:"short", hour:"2-digit", minute:"2-digit", hour12: true }) : "";

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Header */}
      <header className="bg-white border-b border-slate-200 sticky top-0 z-40">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 py-4 flex items-center gap-4">
          <button onClick={() => router.push("/")} className="p-2 rounded-xl hover:bg-slate-100 text-slate-500">
            <ArrowLeft className="w-4 h-4" />
          </button>
          <div className="flex items-center gap-2.5">
            <img src="/logo.svg" alt="" className="w-8 h-8 rounded-xl" />
            <div>
              <h1 className="text-sm font-bold text-slate-900">Inventory Requirements</h1>
              <p className="text-xs text-slate-400">Cumulative order requirements by product</p>
            </div>
          </div>
          {result && (
            <button
              onClick={downloadPNG}
              className="ml-auto flex items-center gap-2 px-4 py-2 bg-slate-900 text-white rounded-xl text-sm font-medium hover:bg-slate-700 transition-colors"
            >
              <Download className="w-4 h-4" />
              Download PNG
            </button>
          )}
        </div>
      </header>

      <main className="max-w-3xl mx-auto px-4 sm:px-6 py-6 space-y-6">

        {/* Date range picker */}
        <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-5">
          <h2 className="text-sm font-semibold text-slate-700 mb-4">Select Order Window</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-500 mb-1.5">From</label>
              <input
                type="datetime-local"
                value={from}
                onChange={(e) => setFrom(e.target.value)}
                className="w-full border border-slate-200 rounded-xl px-3 py-2.5 text-sm text-slate-700 focus:outline-none focus:ring-2 focus:ring-brand-500"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-500 mb-1.5">To</label>
              <input
                type="datetime-local"
                value={to}
                onChange={(e) => setTo(e.target.value)}
                className="w-full border border-slate-200 rounded-xl px-3 py-2.5 text-sm text-slate-700 focus:outline-none focus:ring-2 focus:ring-brand-500"
              />
            </div>
          </div>
          <button
            onClick={generate}
            disabled={loading || !from || !to}
            className="mt-4 w-full py-2.5 bg-brand-600 text-white rounded-xl text-sm font-semibold hover:bg-brand-700 disabled:opacity-50 flex items-center justify-center gap-2 transition-colors"
          >
            <RefreshCw className={`w-4 h-4 ${loading ? "animate-spin" : ""}`} />
            {loading ? "Fetching from Odoo…" : "Generate Report"}
          </button>
        </div>

        {error && (
          <div className="bg-red-50 border border-red-100 rounded-2xl p-4 text-sm text-red-600">
            {error}
          </div>
        )}

        {/* Results */}
        {result && (
          <div ref={printRef} className="space-y-4 bg-white rounded-2xl border border-slate-200 shadow-sm p-5">
            {/* Report header (shown in PNG) */}
            <div className="flex items-start justify-between border-b border-slate-100 pb-4">
              <div>
                <div className="flex items-center gap-2 mb-1">
                  <Package className="w-5 h-5 text-brand-600" />
                  <h2 className="text-base font-bold text-slate-900">Inventory Requirements</h2>
                </div>
                <p className="text-xs text-slate-500">{fromLabel} → {toLabel}</p>
              </div>
              <div className="text-right">
                <div className="text-2xl font-bold text-slate-900">
                  {result.categories.reduce((s, c) => s + c.products.reduce((p, pr) => p + pr.totalPacks, 0), 0)}
                </div>
                <div className="text-xs text-slate-400">total packs</div>
              </div>
            </div>

            {result.categories.length === 0 ? (
              <div className="py-10 text-center text-slate-400 text-sm">
                No confirmed orders found in this window
              </div>
            ) : (
              <div className="space-y-3">
                {result.categories.map((cat) => (
                  <CategoryBlock key={cat.name} cat={cat} />
                ))}
              </div>
            )}

            <p className="text-xs text-slate-300 text-right pt-2">
              Generated by Uncompromised Dashboard · {new Date().toLocaleString("en-IN")}
            </p>
          </div>
        )}

      </main>
    </div>
  );
}
